<?php

require_once("connexion_pdo.php");

if(isset($_POST['submitClick']))
{

  if(isset($_POST['acceptCheck']))
{
     
     $mail = $_POST['inputEmail'];

    /* if(filter_var($mail, FILTER_VALIDATE_EMAIL) === false)
     {

           $sMess=' Votre Mail n\' est pas valide';

     }else{*/

                  $pseudo = $_POST['inputPseudo'];
                  $age = $_POST['inputAge'];
                  $password = $_POST['inputPassword'];
                  

                  
                                   
                                   // verif pseudo et mail
                                   $CheckPseudo=$dbh->prepare("SELECT * FROM users WHERE pseudo=:pseudo");
                                   $CheckPseudo->bindParam(':pseudo',$pseudo,PDO::PARAM_STR);

                                   $CheckMail=$dbh->prepare("SELECT * FROM users WHERE email=:email");
                                   $CheckMail->bindParam(':email',$mail,PDO::PARAM_STR);
                                   
                                   $CheckPseudo->execute();// executer la requête!!!!
                                   $CheckMail->execute();

                                  /* if(!$veriflogin->execute() OR !$vérifmail->execute())
                                   {

                                     echo ' erreur vérif';
                                   }*/

                                   

                                    
                                    $ResultPseudo=$CheckPseudo->RowCount();
                                    $ResultMail=$CheckMail->RowCount();
                                    
                                    /*echo 'Le login'.$ResultPseudo;
                                    echo 'Le Mail'.$ResultMail;*/


                                    if($ResultLogin == 0 && $ResultMail==0)// alors insertion dans la db
                                    {    
                                        
                                        $hshmdp= password_hash($password, PASSWORD_DEFAULT);
                                        $insert=$dbh->prepare("INSERT INTO users(email,pseudo,age,password) VALUES(:email,:pseudo,:age,:password)");

                                        $insert->bindParam(':email',$mail,PDO::PARAM_STR,20);
                                        $insert->bindParam(':pseudo',$pseudo,PDO::PARAM_STR,20);
                                        $insert->bindParam(':age',$age,PDO::PARAM_INT,12);
                                        $insert->bindParam(':password',$hshmdp,PDO::PARAM_STR,20);
                                        $insert->execute();


                                       //header('Location: Index.html');
                                        header('Location: SignIn.php');



                                    }
                                    else if($ResultLogin>0)
                                    {
                                        $sMess='Login déjà existant';

                                    }

                                   else if($ResultMail>0)
                                   {
                                       $sMess='Mail déjà existant';
                                   }

                        /*}*/

        }else{

          $sMess='Veuillez accepter les termes';
        }
}




$BeginHTML = <<<EOT

<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <link rel="stylesheet" type="text/css" href="bootstrap-css/bootstrap.min.css"><!--classe déjà faite-->
  <link rel="stylesheet" type="text/css" href="bootstrap-css/Login.css">
  <script src="https://kit.fontawesome.com/4e1c428a1b.js" crossorigin="anonymous"></script>
  <title>SignIn</title>
</head>

EOT;

$body = <<<EOT

<body class="text-center">
   
   <div class="container square">

    <form class="form-signin" method="post">
      
      <h1 class="h3 mb-3 font-weight-normal">Inscription</h1>

            <div class="mail"><input type="email" name="inputEmail" class="form-control" placeholder=" Adresse email " required autofocus autocomplete="off"></div>
      <div class="pseudo"><input type="text" name="inputPseudo" class="form-control" placeholder=" Pseudo " required autocomplete="off"></div>
      <div class="age"><input type="text" name="inputAge" class="form-control" placeholder="Age" required autocomplete="off"></div>
      <div class="pw"><input type="password" name="inputPassword" id="inputPassword" class="form-control" placeholder=" Mot de passe " required autocomplete="off"></div>
            <div class="checkbox mb-3 required">
      <input type="checkbox" name="acceptCheck"> Accepter les termes
       </div>
      
 
  </div>

  <div class="submit-new-users"><button type="submit" name="submitClick">Go!</button></div>

  <div class=" container users">Vous avez déjà un compte?<br><a href="Login.html">Connectez-vous!</a></div>
  
  
  <!--&copy;-->
  <?php echo '<h4>'.$sMess.'</h4>'; ?>
    </form>
    
    
    
    <p class="mt-5 mb-3 text-muted">Projet Web 2019-2020</p>
   
</body>

EOT;

$EndHTML = <<<EOT
</html>
<!-- 'required' attribut => input field must be filled out before submitting the form-->
<!-- 'autofocus' attribut => input focused on, here outline is blue-->
EOT;

//***************************************************************************************
// Partie Affichage
//***************************************************************************************
echo $BeginHTML.$body.$EndHTML;



//***************************************************************************************
// Fermeture connexion SQL 
//***************************************************************************************

$dbh = NULL;
