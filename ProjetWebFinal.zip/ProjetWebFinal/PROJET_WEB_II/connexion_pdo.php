<?php


// on défini les paramètre de connexion à la DB
function ConnectToDB($Host,$Db,$User,$Pass){
	$host=$Host;
	$db=$Db;
	$user=$User;
	$pass=$Pass;

	// Définition des variables de connexion

	$dsn = "mysql:host=$host;dbname=$db";//data source name
	$dbh = null;

	//**************************************
	// connexion à mysql et à la db
	//**************************************
	try 
	{
		$dbh = new PDO($dsn, $user, $pass); //db handle
	} 
	catch (PDOException $e) 
	{
		die( "Erreur ! : " . $e->getMessage() );
	}
	return $dbh;
}


