<?php
	session_start();
	session_destroy();
	Header("Location: Home_WebPage.php");
?>