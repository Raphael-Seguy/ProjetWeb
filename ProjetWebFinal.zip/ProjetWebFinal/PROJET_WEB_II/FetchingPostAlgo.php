<?php
	require_once("connexion_pdo.php");
	$dbh = null;
	session_start();
	if(isset($_SESSION['pseudo'])&&$_SESSION['pseudo']!=""){
		try{
			$dbh=ConnectToDB('localhost','bd_website','Raphael','123456789');
			GetNextBestPost($dbh);
		}catch(Exception $e){
			echo "Error";
		}
	}else{
		echo "Not Connected";
	}
	function GetNextBestPost($dbh){
		if($_REQUEST["Action"]="FetchNewPost"){
			if(isset($_GET['IDUser'])){
				$Friends = GetFriendList($_GET['IDUser'],$dbh);
				$Post;
				$iIndex = 0;
				$LookupMode="MostPopular";
				foreach ($Friends as $Friend => $ID) {
					$Post[$ID] = GetFriendPost($ID,$dbh);
				}
				$Mode="Unknown";
				if(sizeof($Friends)>=1){
					$Mode="Friend";
				}
				$IDNewPost = GetNewPost($_GET['IDUser'],$Mode,$dbh);
				if(sizeof($IDNewPost)==0 && $Mode=="Friend"){
					$Mode="Unknown";
					$IDNewPost = GetNewPost($_GET['IDUser'],$Mode,$dbh);
				}
				if(sizeof($IDNewPost)==0){
					$IDNewPost=GetOldLikedPost($_GET['IDUser'],$dbh);
					$LookupMode="Random";
				}
				if(sizeof($IDNewPost)==0){
					$IDNewPost=GetAllThePost($dbh);
					$LookupMode="Random";
				}
				if(sizeof($IDNewPost)!=0){
					if($LookupMode!=="Random"){
						$ratioList = BuildRatioOn($IDNewPost,$dbh);
						if(sizeof($ratioList)!=0){
							$Post = GetMaximum($ratioList);
							echo $Post;
						}else{

						}
					}else{
						$Post=$IDNewPost[array_rand($IDNewPost)];
						echo $Post;
					}
				}

			}
		}
	}
	function GetMaximum($List){
		$Max = 0;
		$keys = array_keys($List);
		$keyMax = $keys[0];
		foreach ($List as $key => $value) {
			if($value>$Max){
				$Max=$value;
				$keyMax = $key;
			}
		}
		return $keyMax;
	}
	function GetAllThePost($dbh){
		$Query=$dbh->prepare("SELECT `id_post` FROM `post`");

		if(!$Query->execute()){
			echo "Error : Failed to fetch all the post";
		}else{
			$ListPost = [];
			while (($result = $Query->fetch(PDO::FETCH_ASSOC))!=null) {
				$ListPost[]=$result['id_post'];
			}
			return $ListPost;
		}
	}
	function GetOldLikedPost($idUser,$dbh){
		$Query = $dbh->prepare("SELECT `post`.`id_post` FROM `post` WHERE `post`.`id_post` in (SELECT `history`.`id_post` FROM `history` WHERE `history`.`id_user`=:idUser AND `history`.`liked`=1)");
		$Query->bindParam(':idUser',$idUser,PDO::PARAM_INT);
		
		if(!$Query->execute()){
			echo "Error : Failed to recover old liked post";
		}else{
			$ListOldOne = [];
			while(($result = $Query->fetch(PDO::FETCH_ASSOC))!=null){
				$ListOldOne[] = $result['id_post'];
			}
			
		}
		return $ListOldOne;
	}
	function GetNewPost($idUser,$Mode,$dbh){
		$ListNewPost;
		if($Mode=="Unknown"){
			$Query = $dbh->prepare("SELECT `id_post` FROM (SELECT `id_post` FROM `post` WHERE `post`.`id_user` NOT IN (SELECT `id_user` FROM `post` INNER JOIN `relation` WHERE (`post`.`id_user`=`relation`.`id_userinput` AND `relation`.`id_usersource`=:idUser AND `relation`.`id_userinput`!=:idUser)) AND `post`.`id_user`!=:idUser ) AS `temp` WHERE `temp`.`id_post` not in (SELECT `id_post` FROM history WHERE history.`id_user`=:idUser)");
			$Query->bindParam(":idUser",$idUser,PDO::PARAM_INT);
		}else{
			//Get all the post that haven't been seen by the user and coming from his friends
			$Query = $dbh->prepare("SELECT `id_post` FROM (SELECT `id_post` FROM `post` WHERE `post`.`id_user` IN (SELECT `id_user` FROM `post` INNER JOIN `relation` WHERE (`post`.`id_user`=`relation`.`id_userinput` AND `relation`.`id_usersource`=:idUser AND `relation`.`id_userinput`!=:idUser)) AND `post`.`id_user`!=:idUser ) AS `temp` WHERE `temp`.`id_post` not in (SELECT `id_post` FROM history WHERE history.`id_user`=:idUser)");
			$Query->bindParam(":idUser",$idUser,PDO::PARAM_INT);
		}
		if(!$Query->execute()){
			echo "Erreur : Failed to recover New post (Unknown/Friend)";
		}else{
			$ListNewPost = [];
			while (($result=$Query->fetch(PDO::FETCH_ASSOC))!=null) {
				$ListNewPost[] = $result['id_post'];	
			}
		}
		return $ListNewPost;
	}
	function BuildRatioOn($IdList,$dbh){
		$ListRatio = [];
		foreach ($IdList as $iIndex => $sInformation) {
			$Query = $dbh->prepare("SELECT Count(*) AS NBVue,SUM(`liked`) AS NBLike FROM `history` WHERE `id_post`=:idPost");
			$Query->bindParam(":idPost",$sInformation,PDO::PARAM_INT);
			if(!$Query->execute()){
				echo "Erreur : Failed to get the information needed to build ratio";
			}else{
				$result = $Query->fetch(PDO::FETCH_ASSOC);
				$key = $sInformation;
				
				if($result["NBVue"]>0){
					$ListRatio[$key]=(($result["NBLike"]/$result["NBVue"])*100);
				}else{
					$ListRatio[$key]=0;
				}
			} 
		}
		return $ListRatio;
	}
	function GetFriendPost($IDUser,$dbh){
		$Query = $dbh->prepare("SELECT * From post where id_user=:idUser");
		$Query->bindParam(":idUser",$IDUser,PDO::PARAM_INT);
		if(!$Query->execute()){
			echo "Erreur : Unable to recover friend's post";
		}else{
			$IDPostArray = [];
			while (($result = $Query->fetch(PDO::FETCH_ASSOC))!=null) {
				$IDPostArray[]=$result["id_post"];
			}
			return $IDPostArray;
		}
	}
	function GetFriendList($IDUser,$dbh){
		$Query = $dbh->prepare("SELECT * From relation Where id_usersource=:idUser");
		$Query->bindParam(":idUser",$IDUser,PDO::PARAM_INT);

		if(!$Query->execute()){
			echo "Erreur : Failed to recover the user's friend list";
		}else{
			$IDUser;
			$FriendsArray=[]	;
			while (($result = $Query->fetch(PDO::FETCH_ASSOC))!=null) {
				$IDUser="";
				if($result["id_usersource"]!=$IDUser){
					$IDUser=$result["id_usersource"];
				}else if($result["id_userinput"]!=$IDUser){
					$IDUser=$result["id_userinput"];
				}
				if(mb_strlen($IDUser)>=1){
					$FriendsArray[] = $IDUser;
				}
			}
			return $FriendsArray;
		}
	}
?>