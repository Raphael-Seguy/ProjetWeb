<?php
	require_once("connexion_pdo.php");
	session_start();
	$dbh = null;
	if(isset($_SESSION['pseudo'])&&$_SESSION['pseudo']!=""){
		if(isset($_SESSION['level']) && $_SESSION['level']=1){
			//$dbh=ConnectToDB('localhost','bd_website','Raphael','123456789');
			$dbh = ConnectTODB('localhost','projetweb','user','imtheuser');
		}else{
			header('Location: Connection.php');
		}
	}else{
		header('Location: Connection.php');
	}
?>
<!DOCTYPE html>
<html>
<head>
	<title>Admin Page</title>
	<meta charset="utf-8">
	<link rel="stylesheet" type="text/css" href="bootstrap-css/Index.css">
	<link rel="stylesheet" href="fontawesome-free-web/css/font-awesome.min.css">
	<link rel="stylesheet" type="text/css" href="bootstrap-css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="./CSS/AdminPage_Style.css">
	<link rel="stylesheet" href="fontawesome-free-web/css/font-awesome.min.css"><!--TESTER en local-->
	<script src="./JS/Cookie_Organisation_Script.js"></script>
	<script src="https://kit.fontawesome.com/4e1c428a1b.js" crossorigin="anonymous"></script>
</head>
<body onload='setCookie("CurrentPage",window.location.href,999);'>
	<nav class="navbar navbar-inverse navbar bg-dark navbar-dark"><!--navbar bg-dark navbar-dark-->
	  <div class="container-fluid">
	    <div class="navbar-header">
	      <a class="navbar-brand" href="#"><h1>QuickPic</h1></a>
	    </div>

	     
	      <!--<div class="input-group-btn">
	      <button class="btn btn-default" type="submit">
	       <i class="fas fa-search"></i>
	      </button>-->

	    <form class="formulaire" action="/action_page.php"><!--navbar-form navbar-left-->
	      <div class="form-group">
	           <div class="p-2 bd-highlight right">
	        <ul>
	      <div class="d-flex justify-content-end bd-highlight mb-3 flex">
	    <div class="p-2 bd-highlight settings"><button type="button" class="btn" onclick='onClickHandler("Menue")'><i class="fas fa-bars"></i></button></div>
	    <div class="p-2 bd-highlight users"><a class="aref" href="TempProfilePage.html"><li class="btn"><i class="fas fa-user-circle"></i></li></a></div>
	      </ul>
	  </div>

	    </div>
	    </form>
	  </div>
	</nav>
	<div id="FalseBody">
		<div id="AdminPageContent" class="rounded">
			<div id="VisualPart" class="text-center">
				<h1 id="Title">Admin Controle Room</h1>
				<div id="TablePicker">
					<p id="Instruction

					ctTable">Select a table</p>
					<select id="PickTable" onchange="OnChangeHandler('PickTable')">
						<option value=""></option>
						<option value="user">User</option>
						<option value="post">Post</option>
						<option value="relation">Relation</option>
						<option value="history">History</option>
						<option value="moderator">Moderator</option>
						<option value="comment">Comment</option>
					</select>
				</div>
				<div id="AdminVue">
				</div>
				<div id="AdminVueControle">
				</div>
			</div>
			<div id="ControlPart">
				<div id="AdminControle">
					<div id="MainAction">
						<div id="ActionOnTheTableInGeneral">
							<h5>Menue pour les actions générales</h5><br>
							<select id="AdminOperationTable">
								<option></option>
							 	<option>Update Index</option>
							 	<option>Clear Table</option>
							</select><br>
							<input type="submit" id="ConfirmedTableAction" name="ConfirmedTableAction" onclick='onClickHandler("ConfirmedTableAction")'>
						</div>

						<div id="ActionOnCertainElement">
							<h5>Menue pour les actions sur certain éléments</h5><br>
							<select id="AdminOperationElements" onchange='OnChangeHandler("ShowTheCorrespondingMenue")'>
								<option></option>
							 	<option>Remove</option>
							 	<option>Edit</option>
							</select>
						</div>
					</div>
					<center>
						<div id="TableSpecific">
							<div id="ModifyMenue">
								
							</div>
							<div id="RemoveMenue">
								<button id="RemoveConfirmed" onclick='onClickHandler("RemoveSelectedItem")'>Confirmez</button>
							</div>
						</div>
					</center>
				</div>
			</div>
		</div>
	</div>
	<div id="Menue" class="sidenav">
  		<a href="javascript:void(0)" class="closebtn" id="closebtn" onclick='onClickHandler("closebtn")'>&times;</a>
  		<a href="Home_WebPage.php" onclick='onClickHandler("Acted")'>See Post</a>
  		<a href="FullMap.php" onclick='onClickHandler("Acted")'>See full Map</a>
  		<a href="Deconnection.php" onclick='onClickHandler("Diconnect")'>Disconnect</a>
	</div>
	<script type="text/javascript" src="./JS/AdminPage_Interactions.js"></script>
</body>
</html>