<?php
  require_once("connexion_pdo.php");
  session_start();
 // $dbh = ConnectToDB('localhost','bd_website','Raphael','123456789');
  $dbh = ConnectTODB('localhost','projetweb','user','imtheuser');
  $sError="";
  function CheckConnection($dbh,$Query,$sLogin,$sPass){
    if(isset($_SESSION['pseudo']) && isset($_GET['LastPseudo'])){
      if($_GET['LastPseudo']!=$_SESSION['pseudo']){
        session_destroy();
        session_start();
      }
    }
    $sError="";
    $resultat=$dbh->prepare($Query);
    $resultat->bindParam(':Login',$sLogin,PDO::PARAM_STR,255);
    if(!$resultat->execute()){
      $sError = 'Probleme de requête!! Connexion via pseudo';
    }else{
      $iNbResultat = $resultat->rowCount();
      if($iNbResultat>1){
        $sError = 'Probleme de base de Données dupliquat!!!';
      }elseif ($iNbResultat==1) {
        $row = $resultat->fetch(PDO::FETCH_ASSOC);
        $hshPass=$row['password'];
        if(password_verify($sPass, $hshPass)){
          $_SESSION['id_user'] = $row['id_user'];
          $_SESSION['email'] = $row['email'];
          $_SESSION['pseudo'] = $row['pseudo'];
          $_SESSION['age'] = $row['age'];
          $_SESSION['level'] = $row['level'];
          $_SESSION['theme'] = $row['theme'];
          $_SESSION['photo'] = $row['photo'];
          $_SESSION['java_cookie']=$_POST['bRememberMe'];
          header('Location: Home_WebPage.php');
        }else{
          $sError = 'Probleme with your Username/password';
        }
      }else{
        $sError = 'Probleme with your Username/password';
      }
    }
    return $sError;
  }
  if(isset($_POST)){
    if(isset($_POST['slogin'])&&isset($_POST['sPass'])){
      $sLogin = $_POST['slogin'];
      $sPass = $_POST['sPass'];
      if(stripos($sLogin,"@")!=FALSE){
        $Query="SELECT * FROM `user` WHERE email=:Login";
        $sError=CheckConnection($dbh,$Query,$sLogin,$sPass);
      }else{
        $Query="SELECT * FROM `user` WHERE pseudo=:Login";
        $sError=CheckConnection($dbh,$Query,$sLogin,$sPass);
      }
    }
  }
?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<link rel="stylesheet" type="text/css" href="bootstrap-css/bootstrap.min.css"><!--classe déjà faite-->
	<link rel="stylesheet" type="text/css" href="./CSS/Connection.css">
	<script src="https://kit.fontawesome.com/4e1c428a1b.js" crossorigin="anonymous"></script>
  <script src="./JS/Cookie_Organisation_Script.js"></script>
  <script src="./JS/Connection_Interaction.js"></script>
	<title>Home</title>
</head>
<body class="text-center">
   
   <div class="container square">

   	<form class="form-login" method="POST" action="" autocomplete="off">
   		
   		<h1 class="h3 mb-3 font-weight-normal">Connexion</h1>

   		<div class="mail"><input type="text" name="slogin" id="sInputLogin" class="form-control" placeholder=" Adresse email ou Pseudo " autocomplete="off" <?php if(isset($_GET['LastPseudo'])){echo 'value="'.$_GET['LastPseudo'].'" onchange="verify(\''.$_GET['LastPseudo'].'\');"';} ?> required autofocus></div>
   		<div class="pw"><input type="password" name="sPass" id="sInputPassword" class="form-control" placeholder=" Mot de passe " required></div>
      <?php echo $sError ?>
  		<div class="checkbox mb-3">
      <input type="checkbox" name="bRememberMe" placeholder="remember-me"> Se souvenir de moi
  </div>
   
  <div><button type="submit" onclick="">Sign in</button></div>

  <div class="restore-pw"><a href="ForgotPassword.php" name="restore-pw">Mot de passe oublié?</a></div>

  </div>

  <div class="container new-users">Vous n'avez pas de compte?<br><a href="SignIn.php">Inscrivez-vous!</a></div>
  
  
  <!--&copy;-->
   	</form>

   	<p class="mt-5 mb-3 text-muted">Projet Web 2019-2020</p>
   
  

</body>

</html>
