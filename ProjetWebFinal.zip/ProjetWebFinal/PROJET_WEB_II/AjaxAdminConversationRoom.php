<?php
require_once("connexion_pdo.php");
$dbh = null;
session_start();
if(isset($_SESSION['pseudo'])&&$_SESSION['pseudo']!=""){
	if(isset($_SESSION['level']) && $_SESSION['level']==1){
		//$dbh=ConnectToDB('localhost','bd_website','Raphael','123456789');
		$dbh = ConnectTODB('localhost','projetweb','user','imtheuser');
		if(isset($_REQUEST['Action'])){
			if($_REQUEST['Action']=="FetchTable"){
				$a_sListColumns=[];
				$sListOfColumnName="";
				$sListOfInformationByLine="";
				$Condition=1;
				$QueryColumnName=$dbh->prepare("SELECT COLUMN_NAME FROM INFORMATION_SCHEMA.COLUMNS WHERE `TABLE_SCHEMA`='bd_website' AND `TABLE_NAME`=:TableName");
				$QueryColumnName->bindParam(':TableName',$_GET['TableName'],PDO::PARAM_STR,64);
				if(!$QueryColumnName->execute()){
					echo "Erreur : Fetching Column Names";
				}else{
					$sListOfColumnName="";
					while (($ColumnName = $QueryColumnName->fetch(PDO::FETCH_ASSOC))!=null) {
						$sListOfColumnName.=$ColumnName['COLUMN_NAME']."%COLSEPARATOR%";
						$a_sListColumns[] = $ColumnName['COLUMN_NAME'];
					}
					if(mb_strlen($sListOfColumnName)>1){
						$sListOfColumnName=substr($sListOfColumnName, 0,mb_strlen($sListOfColumnName)-14);
					}
				}
				$QueryInformation=$dbh->prepare("SELECT * FROM ".$_GET['TableName']." WHERE 1");
				if(!$QueryInformation->execute()){
					echo "Erreur";
				}else{
					$sListOfInformationByLine="";
					while (($result = $QueryInformation->fetch(PDO::FETCH_ASSOC))!=null) {
						$sInformation="";
						foreach ($a_sListColumns as $ColumnName) {
							$sInformation.=$result[$ColumnName]."%COLSEPARATOR%";
						}
						if(mb_strlen($sInformation)>1){
							$sInformation=substr($sInformation, 0,mb_strlen($sInformation)-14);
						}
						$sListOfInformationByLine.=$sInformation.'%LINESEPARATOR%';
					}
					if(mb_strlen($sListOfInformationByLine)>1){
						$sListOfInformationByLine=substr($sListOfInformationByLine, 0,mb_strlen($sListOfInformationByLine)-15);
					}
				}
				

				echo $sListOfColumnName."%INFOSEPARATOR%".$sListOfInformationByLine;
			}else if($_REQUEST['Action']=="ResetIndex"){
				$Query = $dbh->prepare('SET @TableName=:sTableName;SET @Id=:sID;SET @num := 0;SET @r=CONCAT("UPDATE ",@TableName," SET ",@Id," = @num := (@num+1);");SET @s=CONCAT("ALTER TABLE ",@TableName," AUTO_INCREMENT =1;"); PREPARE stmt1 FROM @r; EXECUTE stmt1; PREPARE stmt2 FROM @s; EXECUTE stmt2;');
				$Query->bindParam(":sTableName",$_GET['TableName'],PDO::PARAM_STR,64);
				$Query->bindParam(":sID",$_GET['IndexName'],PDO::PARAM_STR,64);
				echo $_GET['TableName'];
				echo $_GET['IndexName'];
				if(!$Query->execute()){
					echo "Failed";
				}else{
					echo "worked";
				}
			}else if($_REQUEST['Action']=="EmptyTable"){
				$Query = $dbh->prepare("SET @Table = :sTableName;SET @s = CONCAT('DELETE FROM ', @Table);PREPARE stmt1 FROM @s;EXECUTE stmt1; ");
				$Query->bindParam(":sTableName",$_GET['TableName'],PDO::PARAM_STR,64);
				if(!$Query->execute()){
					echo "Failed";
				}else{
					echo "Worked";
				}
			}else if ($_REQUEST['Action']=="RemoveItem") {
				$Query = $dbh->prepare("SET @IdCol = :idName;SET @Table = :sTableName;SET @s = CONCAT('DELETE FROM ', @Table,' WHERE ',@IdCol,'=',:idElement); PREPARE stmt1 FROM @s; EXECUTE stmt1; ");
				$Query->bindParam(":sTableName",$_GET['TableName'],PDO::PARAM_STR,64);
				$Query->bindParam(":idName",$_GET['IndexName'],PDO::PARAM_STR,64);
				$Query->bindParam(":idElement",$_GET['IDItem'],PDO::PARAM_INT);
				if(!$Query->execute()){
					echo "Failed";
				}else{
					echo "worked";
				}
			}else if ($_REQUEST['Action']=="EditElement") {
				var_dump($_GET);
				$Query = $dbh->prepare("SELECT `DATA_TYPE`,`CHARACTER_MAXIMUM_LENGTH` FROM `information_schema`.`COLUMNS` WHERE `TABLE_SCHEMA`='bd_website' AND `TABLE_NAME`=:sTabName AND `COLUMN_NAME`=:sColName");
				$Query->bindParam(":sTabName",$_GET['TableName'],PDO::PARAM_STR,64);
				$Query->bindParam(":sColName",$_GET['ConcernedCol'],PDO::PARAM_STR,64);
				if(!$Query->execute()){
					echo "Error";
				}else{
					$result = $Query->fetch(PDO::FETCH_ASSOC);
					$VarType=$result['DATA_TYPE'];
					$VarLengthMax = $result['CHARACTER_MAXIMUM_LENGTH'];
					$sRequest = "UPDATE ".$_GET['TableName']." SET ".$_GET['ConcernedCol']."=:idNewValue WHERE ".$_GET['IndexName']."=:idElement";
					echo $sRequest."<br>";
					$Query = $dbh->prepare($sRequest);
					$Query->bindParam(":idElement",$_GET['IDItem'],PDO::PARAM_INT);
					if($VarType=="varchar" || $VarType=="longtext"){
						$Query->bindParam(":idNewValue",$_GET['NewValue'],PDO::PARAM_STR,$VarLengthMax);
					}else{
						echo "Number";
						$Query->bindParam(":idNewValue",$_GET['NewValue'],PDO::PARAM_INT);
					}
					if(!$Query->execute()){
						echo "Failed";
					}else{
						echo "Worked";	
					}
				}
			}else{
				echo "Request Not Found";
			}
		}
	}
}	
?>