<?php

require_once("connexion_pdo.php");
//$dbh=ConnectToDB('localhost','bd_website','Raphael','123456789');
$dbh = ConnectTODB('localhost','projetweb','user','imtheuser');
$sMess='';
$path='';
if(isset($_POST['submitClick']))
{

  if((isset($_POST['acceptCheck']) && $_POST['acceptCheck']==true) && (isset($_POST['androidCheck']) && $_POST['androidCheck']==true))
{
     
     $mail = $_POST['inputEmail'];

    /* if(filter_var($mail, FILTER_VALIDATE_EMAIL) === false)
     {

           $sMess=' Votre Mail n\' est pas valide';

     }else{*/

                  $pseudo = $_POST['inputPseudo'];
                  $age = $_POST['inputAge'];
                  $password = $_POST['inputPassword'];
                  $tmp_name = $_FILES['inputFile']['tmp_name'] or null;
                  $name = $_FILES['inputFile']['name'] or null;
                  

                  
                                   // verif pseudo et mail
                                   $CheckPseudo=$dbh->prepare("SELECT * FROM user WHERE pseudo=:pseudo");
                                   $CheckPseudo->bindParam(':pseudo',$pseudo,PDO::PARAM_STR);

                                   $CheckMail=$dbh->prepare("SELECT * FROM user WHERE email=:email");
                                   $CheckMail->bindParam(':email',$mail,PDO::PARAM_STR);
                                   
                                  try {
                                    $CheckPseudo->execute();
                                    $ResultPseudo=$CheckPseudo->rowCount();
                                  } catch (PDOException $e) {
                                    $ResultPseudo=10;
                                  }
                                  try{
                                    $CheckMail->execute();
                                    $ResultMail=$CheckMail->rowCount();
                                  }catch(PDOException $e){
                                    $ResultMail=10;
                                  }
                                  if($ResultPseudo == 0 && $ResultMail==0)// alors insertion dans la db
                                  { 
                                    if(isset($name) && !is_null($name)){
                                      $folder = "./ImageStorage/Profile/";
                                      $extension = pathinfo($name, PATHINFO_EXTENSION);
                                      $name = "ProfilePic#".$_POST["inputPseudo"];
                                      $sMess=var_dump($name);
                                      $path = $folder.$name.".".$extension;
                                      try{
                                        move_uploaded_file($tmp_name,$path);
                                        $sMess="Went the right way";
                                      }catch(Exception $e){
                                        $sMess="Error";
                                      }
                                        
                                      $insert=$dbh->prepare("INSERT INTO user(email,pseudo,age,password,photo) VALUES(:email,:pseudo,:age,:password,:photo)");
                                    }else{
                                      $insert=$dbh->prepare("INSERT INTO user(email,pseudo,age,password) VALUES(:email,:pseudo,:age,:password)");
                                    }
                                    $hshmdp= password_hash($password, PASSWORD_DEFAULT);
                                    $iBaseLevel=0;
                                    $insert->bindParam(':email',$mail,PDO::PARAM_STR,255);
                                    $insert->bindParam(':pseudo',$pseudo,PDO::PARAM_STR,255);
                                    $insert->bindParam(':age',$age,PDO::PARAM_INT,11);
                                    $insert->bindParam(':password',$hshmdp,PDO::PARAM_STR,255);
                                    if(isset($name) && !is_null($name)){
                                      $insert->bindParam(':photo',$path,PDO::PARAM_STR,255);
                                    }

                                    try {

                                      $insert->execute();
                                      Header("Location: Connection.php");
                                    }catch (PDOException $e) {

                                      echo "Inscription Failed: ".$e->getMessage();

                                    }
                                      


                                     



                                }
                                else if($ResultPseudo>0)
                                {
                                  $sMess='Login déjà existant';

                                }

                                else if($ResultMail>0)
                                {
                                  $sMess='Mail déjà existant';
                                }

                        /*}*/

        }else{

          $sMess='Veuillez accepter les termes';
        }
}




$BeginHTML = <<<EOT

<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <link rel="stylesheet" type="text/css" href="./CSS/SignIn-Style.css">
  <link rel="stylesheet" type="text/css" href="./bootstrap-css/bootstrap.min.css"><!--classe déjà faite-->
  <script src="https://kit.fontawesome.com/4e1c428a1b.js" crossorigin="anonymous"></script>
  <title>SignIn</title>
</head>

EOT;

$body = <<<EOT

<body class="text-center">
  <script src="./JS/SignIn_Interactions.js"></script>
  <form class="form-signin" method="post" enctype="multipart/form-data">
    <div class="container square">
     
      <h1 class="h3 mb-3 font-weight-normal">Inscription</h1>

        <div class="mail"><input type="email" name="inputEmail" class="form-control" placeholder=" Adresse email " required autofocus autocomplete="off">
        </div>

        <div class="pseudo"><input type="text" name="inputPseudo" class="form-control" placeholder=" Pseudo " required autocomplete="off">
        </div>

        <div class="age"><input type="number" name="inputAge" id="inputAge" class="form-control" placeholder="Age" required autocomplete="off" min="0" max="200">
        </div>

        <div class="pw"><input type="password" name="inputPassword" id="inputPassword" class="form-control" placeholder=" Mot de passe " required autocomplete="off">
        </div>

        <p>Photo profile</p>
        <div id="profilimg">
          <div id="Preview">
            <img id="profile" src=""></img>
          </div>
          <div>
            <input type="file" id="profilePicture" name="inputFile" onchange="PrintImage(event)" accept="image/*" >
          </div>
        </div>

        <div class="checkbox mb-3 required">
          <input type="checkbox" name="acceptCheck"> Accepter les termes
        </div>

        <div class="checkbox mb-3 required">
          <input type="checkbox" id="androidCheck" name="androidCheck" onclick="checkRobot()"> Je ne suis pas un robot
        </div>
      </div>
      <div class="submit-new-users"><button type="submit" id="submitClick" name="submitClick">Go!</button></div>
      <div class="container users">Vous avez déjà un compte?<br>
        <a href="Connection.php">Connectez-vous!</a>
      </div>
    </div>
  </form>
  
    
  <p class="mt-5 mb-3 text-muted">Projet Web 2019-2020</p>
   
</body>

EOT;

$EndHTML = <<<EOT
</html>
<!-- 'required' attribut => input field must be filled out before submitting the form-->
<!-- 'autofocus' attribut => input focused on, here outline is blue-->
EOT;

//***************************************************************************************
// Partie Affichage
//***************************************************************************************
echo $BeginHTML.$sMess.$body.$EndHTML;



//***************************************************************************************
// Fermeture connexion SQL 
//***************************************************************************************

$dbh = NULL;
