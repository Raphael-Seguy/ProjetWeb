<?php
	require_once("connexion_pdo.php");
	session_start();
	$dbh = null;
	if(isset($_SESSION['pseudo'])&&$_SESSION['pseudo']!=""){
		//$dbh=ConnectToDB('localhost','bd_website','Raphael','123456789');
		$dbh = ConnectTODB('localhost','projetweb','user','imtheuser');
	}else{
		header('Location: Connection.php');
	}
?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>Home</title>
	<link rel="stylesheet" type="text/css" href="bootstrap-css/Index.css">
	<link rel="stylesheet" href="fontawesome-free-web/css/font-awesome.min.css"><!--TESTER en local-->
	<link rel="stylesheet" href="AddOn/leaflet.css" />
	<link rel="stylesheet" type="text/css" href="bootstrap-css/bootstrap.min.css"><!--classe déjà faite-->
	<link rel="stylesheet" type="text/css" href="./CSS/HomeWebPageStyle.css">
	<script src="https://kit.fontawesome.com/4e1c428a1b.js" crossorigin="anonymous"></script>
	<script src="./JS/Cookie_Organisation_Script.js"></script>
	<script src="AddOn/leaflet.js"></script>
	<script src="AddOn/ckeditor/ckeditor.js"></script>
</head>
<body onload="initialise();">
	<input id="currentPost" type="number" hidden="hidden" disabled="disabled" value="">
	<input id="currentAuthor" type="number" hidden="hidden" disabled="disabled" value="">
	<nav class="navbar navbar-inverse navbar bg-dark navbar-dark"><!--navbar bg-dark navbar-dark-->
	  <div class="container-fluid">
	    <div class="navbar-header">
	      <a class="navbar-brand" href="Home_WebPage.php"><h1>QuickPic</h1></a>
	    </div>

	     
	      <!--<div class="input-group-btn">
	      <button class="btn btn-default" type="submit">
	       <i class="fas fa-search"></i>
	      </button>-->

	    <form class="formulaire" action="/action_page.php"><!--navbar-form navbar-left-->
	      <div class="form-group">
	           <div class="p-2 bd-highlight right">
	        <ul>
	      <div class="d-flex justify-content-end bd-highlight mb-3 flex">
	    <div class="p-2 bd-highlight settings"><button type="button" class="btn btnMenue" onclick='OnClickHandler("Menue")'><i class="fas fa-bars"></i></button></div>
	    <div class="p-2 bd-highlight users">
	    	<a class="aref" href="profil.php"><li class="btn btnMenue"><i class="fas fa-user-circle"></i></li></a>
	    	<a class="aref" href="Upload.php"><li class="btn btnMenue"><i class="fas fa-upload"></i></li></a>
	    </div>
	      </ul>
	  </div>

	    </div>
	    </form>
	  </div>
	</nav>
	<div class="divControle" id="RightArrow"><button onclick='OnClickHandler("GetNextPost")'><i class="Controle arrow Ctrlright"></i></button></div>
	<div id="main" class="text-center">
		<center>
			<div class="container square" id="Post">
				<div id="Post_Content">
					<div id="Post_MainInformation">
						<div id="Post_Image">
							<img class="rounded" id="ImagePost" alt="An Image" src="content2.jpg">
						</div>
						<div id="Post_Map">
							<div id="Zemap" class="Zemap"></div>
						</div>
					</div>
					<div id="Post_ExtraInformation">
						<em id="UserName">Name of User</em><em><label>Vue : <span id="NbVue"></span></label></em><em><label>J'aime : <span id="NbLike"></span></label></em>
					</div>
					<div id="Post_Menue">
						<div class="btn-group">
							<button type="button" id="Like" class="btn btn-primary" onclick='OnClickHandler("Like")'><i class="fa fa-heart-o" aria-hidden="true"></i></button>
							<button type="button" id="Follow" class="btn btn-primary" onclick='OnClickHandler("Follow")'><i id="IconFollow" class="fa fa-user-plus" aria-hidden="true"></i></button>
							<button type="button" id="Comment" class="btn btn-primary" onclick='OnClickHandler("Comment")'><i id="LikeReflection" class="fas fa-comments "></i></button>
						</div>
					</div>
				</div>
			</div>
		</center>
	</div>
	<div id="Menue" class="sidenav">
  		<a href="javascript:void(0)" class="closebtn" id="closebtn" onclick='OnClickHandler("closebtn")'>&times;</a>
  		<a href="Profil.php" onclick='onClickHandler("Acted")'>Profile Page</a>
  		<?php if(isset($_SESSION['level']) && $_SESSION['level']==1){echo '<a href="AdminPage.php" onclick="onClickHandler("Acted")">Admin zone</a>';}?>
  		<a href="FullMap.php" onclick='onClickHandler("Acted")'>See full Map</a>
  		<a href="Deconnection.php" onclick='OnClickHandler("Diconnect")'>Disconnect</a>
	</div>
	<!-- Trigger/Open The Modal -->

	<!-- The Modal -->
	<div id="CommentModal" class="modal">
		<div class="modal-header">
			<p class="close rounded-circle" id="CloseBtn" onclick='OnClickHandler("CommentClose")'>&times;</p>
		</div>
	  	<div class="modal-content" id="CommentCargo">
	  	</div>
	  	<div id="modal-footer">
	  		<button class="btn" id="btnCreateComment" onclick='OnClickHandler("CreateComment")'>Write a Comment</button>
	  		<div id="CommentBuildingZone">
  				<textarea id="NewComment" onclick='onClickHandler("Acted")'>
				</textarea>
				<script type="text/javascript">
					CKEDITOR.replace( 'NewComment' );
				</script>
				<div class="btn-group"><button class="btn" id="btnRegister" onclick='OnClickHandler("RegisterChange")'>Confirm</button><button class="btn" id="btnReturn" onclick='OnClickHandler("Return")'>Retour</button></div>
	  		</div>
	  	</div>
	</div>
	<div id="SecretModal" class="modal">
		<div class="Console">
			<input type="text" id="CheatCode" placeholder="Please enter the cheat code" onchange='GetCheat("CheatCode")'>
		</div>
	</div>
	<script src="./JS/HomePage_Interactions.js"></script>
</body>

</html>