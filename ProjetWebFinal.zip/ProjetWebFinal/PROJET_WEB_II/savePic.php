<?php 

   if(!empty($_FILES['file']['name'])){
       
       $upload='upload';
       $directory='./ImageUpload/'; 
       $filename = $_FILES['file']['name'];

  
      // Initialize filecount variable 
      $filecount = 0; 
        
      $files = glob( $directory ."*" ); 
        
      if( $files ) { 
          $filecount = count($files); 
      } 
  
       //---------------ENREGISTREMENT DU FICHIER AVEC UN NOUVEAU NOM----------------------
       /*$cutstring = explode('.',$filename); // 1er param = délimiteur
       $ext = end($cutstring);*/
       $ext = pathinfo($filename, PATHINFO_EXTENSION);
      // echo $ext;
       $filecount+=1;
       $savedname = $upload.$filecount.'.'.$ext;
       //---------------------------------------------------------------------------------
       $directory .=$savedname;
       move_uploaded_file($_FILES['file']['tmp_name'],$directory);
       
       echo '<img src="'.$directory.'"heigth="300" width="300"/>';// show the picture saved!*/
}

?>