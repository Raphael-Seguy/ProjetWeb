<?php 

   if(!empty($_FILES['file']['name'])){
       
       $upload='upload';
       $filename = $_FILES['file']['name'];
       //---------------ENREGISTREMENT DU FICHIER AVEC UN NOUVEAU NOM----------------------
       $cutstring = explode('.',$filename); // 1er param = délimiteur
       $ext = end($cutstring);
       $savedname = $upload.rand(100,999).'.'.$ext;
       //---------------------------------------------------------------------------------
       $location = './ImageUpload/'.$savedname;
       move_uploaded_file($_FILES['file']['tmp_name'],$location);
       
       echo '<img src="'.$location.'"heigth="300" width="300"/>';// show the picture saved!
}

?>