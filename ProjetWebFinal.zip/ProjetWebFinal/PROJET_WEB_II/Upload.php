<?php
      
     /* require_once("navbar.php");
      $navbar = navbar();

      echo $navbar;*/

      require_once("connexion_pdo.php");
      require_once("RecupDataGPS.php");
      session_start();
      $id_user=$_SESSION['id_user'];
      $dbh = ConnectToDB('localhost','projetweb','admin','adminpw');
     // $dbh = ConnectToDB('localhost','bd_website','Raphael','123456789');
       //---------------------SQL--------------------------------------------------------
       if(isset($_POST['btnupload'])){
       
      //echo '<h1>'.'Vous avez appuyer sur btn upload'.'</h1>';
      //echo '<script>alert("upload")</script>';   
       if(!empty($_FILES['file']['name'])){
           
           $MaxSize = 6000000;
           $file = $_FILES['file']['name'];
           //echo $file;

           if($_FILES['file']['size']>=$MaxSize){

             echo " Trop grand ";
           }else{
            
            $ValidExt = array('png','jpg','jpeg');
            $UploadExt = substr($file,strpos($file,'.')+1);

            if(in_array(strtolower($UploadExt),$ValidExt)){// if ext of user is in array of Valid extension
                
                $result = get_image_location($_FILES['file']['name']);
                if(!(gettype($result)=='boolean')){
                     
                     $array = array_values($result);
                     $latitude = $array[0];
                     $longitude = $array[1];
                     /*echo $array[0]."</br>"; 
                     echo $array[1]; */

                
                   $insert=$dbh->prepare("INSERT INTO post(id_user,latitude,longitude,photo) VALUES(:id_user,:latitude,:longitude,:photo)");
                                        $insert->bindParam(':id_user',$id_user,PDO::PARAM_INT);
                                        $insert->bindParam(':latitude',$latitude,PDO::PARAM_STR);
                                        $insert->bindParam(':longitude',$longitude,PDO::PARAM_STR);
                                        $insert->bindParam(':photo',$file,PDO::PARAM_STR,20);

                                        if(! $insert->execute()){

                                          echo 'error connexion DB';
                                        }else{

                                              //echo 'hmm';
                                              header('Home_WebPage.php');
                                        }

                }else{

                  header('InputLocation.php');
                  //echo 'gimme ur location';
                }
                
                                        
                                        

              }else{

                echo '<script>alert(" Extension non valide ")</script>';
              }

            
           }
      }
      
  }
?>
<!DOCTYPE html>
<html>
 <head>
  <title> Upload</title>
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" />
  <!--<link rel="stylesheet" type="text/css" href="bootstrap-css/upload.css">-->
  <link rel="stylesheet" type="text/css" href="./CSS/upload.css">
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.0/jquery.min.js"></script>
 </head>
 <body>
  <br /><br />
  <div class="container" style="width:700px;">
   <h2 align="center">Choisissez une image!</h2>
   <br />
   

   <form method="post" enctype="multipart/form-data">
     <div class="form-group">
       <input type="file" name="file" id="file"/>
     </div>
   <div class="containerPreview">
     <div id="uploadedImage"></div>
   </div>
   
   <div class="form-group">
    <div class="container submit">
    <!--<input type="submit" name="btnupload" id="btnsubmit" value="Go">-->
    <button type="submit" class="btn btn-primary" name="btnupload">Go!</button>
  </div>
  </div>
   </form>
  </div>
 </body>
</html>

<script>
$(document).ready(function(){
 $(document).on('change', '#file', function(){//#id
  
  var file = document.getElementById("file").files[0];
  var img_name = file.name;
  var form_data = new FormData();
  var ext = img_name.split('.').pop().toLowerCase();

  if(jQuery.inArray(ext, ['gif','png','jpg','jpeg']) == -1) 
  {
   alert(" Image invalide, veuillez choisir un format gif,png,jpg ou jpeg ");
  }
  /*var oFReader = new FileReader();
  oFReader.readAsDataURL(document.getElementById("file").files[0]);*/
  
  var fsize = file.size/*||f.fileSize;*/
  if(fsize > 6000000)
  {
    alert(" Veuillez sélectionner une image inférieure à 3 mo"); 
  }
  else
  {
   form_data.append("file",file);
   $.ajax({
    url:"savePic.php",
    method:"POST",
    data: form_data,
    contentType: false,
    cache: false,
    processData: false,
    beforeSend:function(){
     $('#uploadedImage').html("<label class='text-success'>Image Uploading...</label>");
    },   
    success:function(data)
    {
     $('#uploadedImage').html(data);
    }
   });
  }
 });
});
</script>