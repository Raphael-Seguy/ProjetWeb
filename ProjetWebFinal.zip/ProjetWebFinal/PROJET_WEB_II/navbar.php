<?php
function navbar(){
	$navbar ='<nav class="navbar navbar-inverse"><!--navbar bg-dark navbar-dark-->';
  $navbar.='<div class="container-fluid">';
  $navbar.='<div class="navbar-header">';
  $navbar.='<a class="navbar-brand" href="Home_WebPage.php"><h1>QuickPic</h1></a>';
  $navbar.='</div>';
     
  $navbar.='<!--<div class="input-group-btn">';
  $navbar.='<button class="btn btn-default" type="submit">';
  $navbar.='<i class="fas fa-search"></i>';
  $navbar.='</button>-->';
  $navbar.='<form class="formulaire" action="/action_page.php"><!--navbar-form navbar-left-->';
  $navbar.='<div class="form-group">';
  $navbar.='<div class="p-2 bd-highlight right">';
  $navbar.='<ul>';
  $navbar.='<div class="d-flex justify-content-end bd-highlight mb-3 flex">';
  $navbar.='<div class="p-2 bd-highlight users"><button type="button" class="btn" onclick="openSideBar()"><i class="fas fa-bars"></i></button></div>';
  $navbar.='<div class="p-2 bd-highlight settings"><li class="btn"><a class="aref" href="profil.php" >'.'<i class="far fa-user-circle"></i></li></div>';
  $navbar.='</ul>';
  $navbar.='</div>';
  $navbar.='</div>';
  $navbar.='</form>';
  $navbar.='</div>';
  $navbar.='</nav>';
  $navbar.='<!---------------------SIDE BAR-------------------------------------------------------------------------------------------->';
  $navbar.='<div id="Sidebar" class="sidebar">';
  $navbar.='<a href="javascript:void(0)" class="closebtn" onclick="closeSideBar()">&times;</a> <!-- times = "X"-->';
  $navbar.='<a href="Home_WebPage.php">Home</a>';
  if(isset($_SESSION['level']) && $_SESSION['level']==1){$navbar.='<a href="AdminPage.php" onclick="onClickHandler("Acted")">Admin zone</a>';}
  $navbar.='<a href="Deconnection.php"><!--<i class="fas fa-door-open">&nbsp;-->Déconnexion</a>';
  $navbar.='</div>';
  $navbar.='<script type="text/javascript">';
  
  $navbar.='function openSideBar(){';
  $navbar.='document.getElementById("Sidebar").style.width = "250px";';
  $navbar.='}';
  $navbar.='function closeSideBar(){';
  $navbar.='document.getElementById("Sidebar").style.width = "0px";';
  $navbar.='}';
  $navbar.='</script>';
  return $navbar;
}