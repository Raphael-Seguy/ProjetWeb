<?php
	session_start();
	require_once("connexion_pdo.php");
	if(isset($_SESSION['pseudo'])&&$_SESSION['pseudo']!=""){
		//$dbh = ConnectToDB('localhost','bd_website','Raphael','123456789');
		$dbh = ConnectTODB('localhost','projetweb','user','imtheuser');
	}else{
		header('Location: Connection.php');
	}
	function GetElement($sColor){
		$Query = "SELECT * FROM `setting` WHERE (id_setting=:IdSetting)";
		//$dbh = ConnectToDB('localhost','bd_website','Raphael','123456789');
		$dbh = ConnectTODB('localhost','projetweb','user','imtheuser');
		$resultat = $dbh->prepare($Query);
		$resultat->bindParam(':IdSetting',$_SESSION['id_setting'],PDO::PARAM_INT,11);
		if(!$resultat->execute()){
			$sError="Erreur Query";
		}else{
			$a_sColor = $resultat->rowcount();
			switch ($sColor) {
			case 'clrBackgroundColor':
				echo $a_sColor['background_color'];
				break;
			case 'clrBorder':
				echo $a_sColor['border_color'];
				break;
			case 'clrWindow':
				echo $a_sColor['content_background_color'];
				break;
			case 'clrText':
				echo $a_sColor['txtColor'];
				break;
			default:
				break;
			}
		}
		
	}
	
?>
<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8">
		<link rel="stylesheet" type="text/css" href="bootstrap-css/bootstrap.min.css"><!--classe déjà faite-->
		<title>Setting Page</title>
		<link rel="stylesheet" type="text/css" href="CSS/Setting.css">
		<link rel="stylesheet" href="fontawesome-free-web/css/font-awesome.min.css"><!--TESTER en local-->
		<script src="https://kit.fontawesome.com/4e1c428a1b.js" crossorigin="anonymous"></script>
	</head>
	<body>
		<?php
			$sError="";
			$Query = "SELECT * FROM `setting` WHERE (id_setting=:IdSetting)";
			$resultat = $dbh->prepare($Query);
			$resultat->bindParam(':IdSetting',$_SESSION['id_setting'],PDO::PARAM_INT,11);
			if(!$resultat->execute()){
				$sError="Erreur Query";
			}else{
				$row = $resultat->fetch(PDO::FETCH_ASSOC);
				$Style='<style name="Test" type="text/css">
				:root{
					--main_bg_color:'.$row['background_color'].';
					--font_color:'.$row['font_color'].';
					--border_color:'.$row['border_color'].';
					--content_bg_color:'.$row['content_background_color'].';
				}
				*{
					color:var(--font_color);
				}
				body{
					background-color:var(--main_bg_color);
				}
				.Conteneur{
					border-color:var(--border_color);
					background-color:var(--content_bg_color);
				}
				</style>';
				echo $Style;
			}
		?>
		<div class="container square Conteneur">
			<div class="Content">
				<h1 id='title'>Settings</h1>
				<form method="get" action="">
					<?php
						$sForm='<label>Couleur de fonds d\'écran : <input type="color" name="clrBackgroundColor" value="'.GetElement('clrBackgroundColor').'"/></label><br>
						<label>Couleur des bords : <input type="color" name="clrBorder" value="'.GetElement('clrBorder').'"/></label><br>
						<label>Couleur de fonds des fenêtres : <input type="color" name="clrWindow" value="'.GetElement('clrWindow').'"/></label><br>
						<label>Couleur du texte : <input type="color" name="clrText" value="'.GetElement('clrText').'" /></label><br>';
						echo $sForm;
					?>
					<label><input type="submit" name="Check" value="Check"></label>
					<input type="text" name="afterCheck" value="normal" hidden="hidden"><br>
				</form>
			</div>
		</div>
		<script type="text/javascript">
			function Update=
		</script>
	</body>
</html>