function verify(sId){
	if(document.getElementById('sInputLogin')!=sId){
		DeleteAllCookie();
	}
}