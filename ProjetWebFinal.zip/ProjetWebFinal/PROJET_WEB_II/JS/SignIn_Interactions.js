var fDecalageStorage;
var fStepStorage;
function getStep(){
	return fStepStorage;
}
function getDecalage(){
	return fDecalageStorage;
}
function setStep(fStepInput){
	fStepStorage = fStepInput;
}
function setDecalage(fDecalageInput){
	fDecalageStorage=fDecalageInput;
}
function GetSlicesN(fDecalage){
	var ValueN;
	if(fDecalage%2==0){
		return 2;
	}else{
		ValueN=3;
		while(fDecalage%ValueN!=0){
			ValueN+=1;
		}
		alert(ValueN);
		return ValueN;
	}
}
function checkRobot(){
	var bChecked = document.getElementsByName('androidCheck')[0].checked;
	if(bChecked && document.getElementById("ControlModal")==null){
		var ControlModal = document.createElement("DIV");
		var SubmitButton = document.getElementById('submitClick');
		SubmitButton.style.display = "none";
		var fDecalage = Math.floor(Math.random()*4);
		switch(fDecalage){
			case 0:
				fDecalage=72;
				break;
			case 1:
				fDecalage=144;
				break;
			case 2:
				fDecalage=216;
				break;
			case 3:
				fDecalage=288;
				break;
			default:
				alert("Erreur");
				break;
		}
		setStep(72);
		setDecalage(fDecalage);
		var sContent = 	'<div id="ControleHeader">'+
							'<p> Image Controle </p>'+
						'</div>'+
						'<div id="ControleContent">'+
							'<div id="MainControl">'+
								'<div id="TurnRight">'+
									'<button id="btn-right" onclick="RotateRight()" class="btn">&rarr;</button>'+
								'</div>'+
								'<div id="TurnLeft">'+
									'<button id="btn-left" onclick="RotateLeft()" class="btn">&larr;</button>'+
								'</div>'+
								'<div id="ControleContainerContent">'+
									'<div id="ControleContainerImage">'+
										'<img id="ControleImage" src="./ImageControle/Test105.jpg" alt="'+getDecalage()+'">'+
									'</div>'+
								'</div>'+
							'</div>'+
							'<div id="idConfirm">'+
								'<button id="btn-Confirm" onclick="CheckAngle()">Confirmer</button>'+
							'</div>'+
						'</div>';
		var sStyle = 	"<style type=\"text/css\">"+
						
						"#btn-left,#btn-right{"+
							"border:solid blue;"+
						"}"+
						
						"#TurnRight{"+
							"float:right;"+
							"margin-top:33%;"+
						"}"+
						
						"#TurnLeft{"+
							"float:left;"+
							"margin-top:33%;"+
						"}"+
						
						"#ControleHeader{"+
							'height:10%;'+
						"}"+

						"#MainControl{"+
							'height:70%;'+
						'}'+

						"#ControleContent{"+
							"height:90%;"+
						"}"+

						"#idConfirm{"+
							"margin-top:10%;"+
						"}"+

						"#ControleContainerImage{"+
							"margin-left:25%;"+
							"width:60%;"+
							"overflow-y:hidden;"+
						"}"+

						"#ControleImage{"+
							"margin-top : 25%;"+
							"width:65%;"+
							"transform : rotate("+fDecalage+"deg);"+
						"}"+
						
						"#ControleContainerContent{"+
							"display:flex;"+
							"height:100%;"+
						"}"+

						"#ControlModal{"+
							"display:flex;"+
							"flex-direction:column;"+
							"min-width:500px;"+
							"height:50%;"+
							"width:50%;"+
							"margin-top:5%;"+
							"left:25%;"+
							"background-color:white;"+
							"border:solid;"+
							"overflow-y:auto;"+
							"min-height:400px;"+
						"}"+
						
						"</style>";
		ControlModal.className = "modal";
		ControlModal.id = "ControlModal";
		ControlModal.innerHTML = sContent+sStyle;
		document.body.appendChild(ControlModal);
	}else{
		var Modal = document.getElementById("ControlModal");
		if(Modal!=null){
			document.body.removeChild(Modal);
		}
	}
}

function PrintImage(event){
  var image = event.target.files[0];
  var reader = new FileReader();

  var imgTag = document.getElementById("profile");

  imgTag.title = image.name;

  reader.onload = function(event){
    imgTag.src = event.target.result;
  };

  reader.readAsDataURL(image);
}
function RotateRight(){
	var NewAngle;
	var imageStyle = document.getElementById('ControleImage');
	var iAlt = parseInt(imageStyle.alt);
	NewAngle = ((iAlt+getStep())%360);
	imageStyle.style.transform = "rotate("+NewAngle+"deg)";
	imageStyle.alt = NewAngle;
}
function RotateLeft(){
	var NewAngle;
	var imageStyle = document.getElementById('ControleImage');
	var iAlt = parseInt(imageStyle.alt);
	NewAngle = ((iAlt-getStep())%360);
	imageStyle.style.transform = "rotate("+NewAngle+"deg)";
	imageStyle.alt = NewAngle;
}
function CheckAngle(){
	var imageStyle = document.getElementById('ControleImage');
	var CheckBox = document.getElementById('androidCheck');
	if(imageStyle.alt>=-1 && imageStyle.alt<=1){
		CheckBox.checked=true;
	}else{
		CheckBox.checked=false;
	}
	var SubmitButton = document.getElementById('submitClick');
	SubmitButton.style = "display:inline;";
	var Modal = document.getElementById("ControlModal");
	if(Modal!=null){
		document.body.removeChild(Modal);
	}
}