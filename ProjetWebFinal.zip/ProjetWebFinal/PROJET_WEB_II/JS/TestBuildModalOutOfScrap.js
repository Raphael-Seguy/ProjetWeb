function BuildModalPrintIt(){
	var ModalStyle = document.createElement("DIV");
	var sInside = "<style>"+
				  "</style>"+
				  "<p>Heey sweetie</p>";
	ModalStyle.innerHTML = sInside;
	Document.body.appendChild(ModalStyle);
}