  // initialize the map
  var mymap = L.map('Map').setView([42.35, -71.08], 15);

  // load a tile layer
  L.tileLayer('https://api.tiles.mapbox.com/v4/{id}/{z}/{x}/{y}.png?access_token={accessToken}',
    {
		attribution: 'Map data &copy; <a href="https://www.openstreetmap.org/">OpenStreetMap</a> contributors, <a href="https://creativecommons.org/licenses/by-sa/2.0/">CC-BY-SA</a>, Imagery © <a href="https://www.mapbox.com/">Mapbox</a>',
		maxZoom: 100,
		id: 'mapbox.streets',
		accessToken: 'pk.eyJ1Ijoic2FwaG9nYW1lcyIsImEiOiJjazF5emp1dDQwbWNwM2RwY29kMDJ0Y2cwIn0.JuCgfRb9xFq83jdbh9UP8g',
      	minZoom: 1
    }).addTo(mymap);
setInterval(Check, 1000);
function initialise(){
  LoadMap();
  setCookie("CurrentPage",window.location.href,999);
}
function LoadMap(){
	var xmlhttp;
    var RequestCounter;
    var Action = "GetPostPos";
    var idUser;
    var request = "AjaxConversationRoom.php?Action="+Action;

    if (window.XMLHttpRequest){
        // code for IE7+, Firefox, Chrome, Opera, Safari
        xmlhttp=new XMLHttpRequest();
    }else{
        // code for IE6, IE5
        xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
    }
   	xmlhttp.onreadystatechange = function() {
        if (this.readyState == 4 && this.status == 200) {
        	a_sPost = this.responseText.split("/");
        	a_sPost.forEach(AddMarker);
        }
    };
    xmlhttp.open("GET",request,true);
    xmlhttp.send();
}
function onClickHandler(idConcerned){
  setCookie("Active",true,3);
  switch(idConcerned){
    case "Menue":
      document.getElementById("Menue").style.width="250px";
      break;
    case "closebtn":
      document.getElementById("Menue").style.width="0px";
      break;
    case "Diconnect":
      DeleteAllCookie();
      break;
    default :
      break;
  }
}
function AddMarker(item, index){
	info = item.split("#");
	var Lat = info[1];
	var Long = info[2]; 	
	new L.Marker([Lat,Long]).addTo(mymap);
	mymap.invalidateSize();
}