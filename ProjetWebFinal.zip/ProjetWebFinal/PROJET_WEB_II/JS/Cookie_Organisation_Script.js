function setCookie(CookieName,CookieValue,exHours){
	var d = new Date();
	d.setTime(d.getTime() + (exHours*60*60*1000));
	var expires = "expires="+d.toUTCString();
	document.cookie = CookieName+"="+CookieValue+";"+expires+";path=/";
}
function getCookie(CookieName){
	var sIndex = CookieName + "=";
	var CookieGroup = document.cookie.split(';');
 	for(var iIndex = 0; iIndex < CookieGroup.length; iIndex++) {
    	var Cookie = CookieGroup[iIndex];
    	while (Cookie.charAt(0) == ' ') {
      		Cookie = Cookie.substring(1);
    	}
    	if (Cookie.indexOf(sIndex) == 0) {
      		return Cookie.substring(sIndex.length, Cookie.length);
    	}
  	}
  	return "";
}
function checkCookie(CookieName){
	var cookie = getCookie(CookieName);
	if(cookie!=""){
		return true;
	}else{
		return false;
	}
}
function DeleteAllCookie(){
	var CookieGroup = document.cookie.split(';');
 	for(var Cookie in CookieGroup){
        if(CookieGroup[Cookie].split('=')[0]!=="PHPSESSID"){
            DeleteCookie(CookieGroup[Cookie].split('=')[0]);
        }
    }
}
function DeleteCookie(CookieName){
    setCookie(CookieName,"",-24);
}
function Check(){
	if(getCookie("Active")==""){
		sDirectory = window.location.pathname;
		sDirectory = sDirectory.split("/");
		sDirectory=sDirectory[1];
		var xmlhttp;
    	var str = "PHPCookieToJavascript";
    	var Information = "";
    	var sPseudo="";
    	var sName="pseudo";

    	if (window.XMLHttpRequest){
        	// code for IE7+, Firefox, Chrome, Opera, Safari
        	xmlhttp=new XMLHttpRequest();
    	}else{
        	// code for IE6, IE5
        	xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
    	}
   		xmlhttp.onreadystatechange = function() {
        	if (this.readyState == 4 && this.status == 200) {
        		sPseudo=this.responseText;
        		window.location.replace(window.location.protocol+'/'+sDirectory+'/Connection.php?LastPseudo='+sPseudo);
        	}
    	};
    	xmlhttp.open("GET","AjaxConversationRoom.php?Action="+str+"&sName="+sName,true);
    	xmlhttp.send();
		
	}
}