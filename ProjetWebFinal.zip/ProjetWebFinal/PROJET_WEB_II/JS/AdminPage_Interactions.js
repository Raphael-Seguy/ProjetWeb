var AdminOperationTable = document.getElementById("AdminOperationTable");
var AdminOperationElements = document.getElementById("AdminOperationElements");
var ActionOnTheTableInGeneral = document.getElementById("ActionOnTheTableInGeneral");
var ActionOnCertainElement = document.getElementById("ActionOnCertainElement");
var ModifyMenue = document.getElementById("ModifyMenue");
var RemoveMenue = document.getElementById("RemoveMenue");
var AdminVueControle = document.getElementById("AdminVueControle");

var btnConfirmedTableAction = document.getElementById("ConfirmedTableAction");
var btnModifyConfirmed = document.getElementById("ModifyConfirmed");
var btnAddConfirmed = document.getElementById("AddConfirmed");
var btnRemoveConfirmed = document.getElementById("RemoveConfirmed");

var sInput = document.getElementById("sInput");

var divAdminVue = document.getElementById("AdminVue");

Initialise();
setInterval(Check, 1000);

function Initialise(){
	ModifyMenue.style = "display:none;";
	RemoveMenue.style = "display:none;";
	ActionOnTheTableInGeneral.style = "display:none;";
	ActionOnCertainElement.style = "display:none;";
}
function BuildTable(sInformation,sTabName){
	var a_sInformation = sInformation.split("%INFOSEPARATOR%");

	var a_sColumnName;

	var a_sLineContent;

	var a_sColContent;

	var sColumnName = a_sInformation[0];
	var sTableInformation = a_sInformation[1];
	
	var sTable = '<h3 id="TableName">Visualisation table '+sTabName+'</h3><center><table id="Vue" class="table-striped table-hover table-condensed">';
	var sSelect = '<select id="TestingCol"><option value=""></option>';
	var sSelect2 = '<select id="TestingCol2"><option value=""></option>';

	a_sColumnName = sColumnName.split("%COLSEPARATOR%");

	sTable+='<tr id="ColumnName" class="info">';
	for(var iIndexName in a_sColumnName){
		sSelect+='<option id="Option'+iIndexName+'" value="'+a_sColumnName[iIndexName]+'">'+a_sColumnName[iIndexName]+"</option>";
		sSelect2+='<option id="Option'+iIndexName+'" value="'+a_sColumnName[iIndexName]+'">'+a_sColumnName[iIndexName]+"</option>";
		sTable+='<td class="'+a_sColumnName[iIndexName]+'">'+a_sColumnName[iIndexName]+'</td>';
	}
	sTable+='</tr>';
	sSelect+='</select><input type="text" id="LookupValue" name="LookupValue"><button class="btn" onclick="LookupTable();">Confirmez</button>';
	sSelect2+='</select>';
	AdminVueControle.innerHTML=sSelect;
	ModifyMenue.innerHTML = sSelect2+'<input type="text" id="sInput" name="sInput"><button id="ModifyConfirmed" onclick="onClickHandler(\'ModifiedSelectedItem\')">Confirmez</button>';

	a_sLineContent = sTableInformation.split("%LINESEPARATOR%");
	for(var iIndexLine in a_sLineContent){
		a_sColContent=a_sLineContent[iIndexLine].split("%COLSEPARATOR%");
		sTable+='<tr id="Line'+iIndexLine+'">';
		for(var iIndexCol in a_sColContent){
			sTable+='<td id="Line='+iIndexLine+'&Col='+a_sColumnName[iIndexCol]+'" class="'+a_sColumnName[iIndexCol]+' cell">'+a_sColContent[iIndexCol]+'</td>';
		}
		sTable+='<td><input type="checkbox" id="Line='+iIndexLine+'&Col=Checkbox" class="checkbox cell" onchange=\'SelectElement("Line='+iIndexLine+'&Col=Checkbox")\'></tr>';
	}


	sTable+='</table></center>';
	divAdminVue.innerHTML = sTable;
}
function EmptyTable(){
	var SelectedTable = document.getElementById("PickTable");

	var xmlhttp;
	var str = "EmptyTable";
	var sName = SelectedTable.value;

	if (window.XMLHttpRequest){
    	// code for IE7+, Firefox, Chrome, Opera, Safari
    	xmlhttp=new XMLHttpRequest();
	}else{
    	// code for IE6, IE5
    	xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
	}
		xmlhttp.onreadystatechange = function() {
    	if (this.readyState == 4 && this.status == 200) {
    	}
	};
	xmlhttp.open("GET","AjaxAdminConversationRoom.php?Action="+str+"&TableName="+sName,true);
	xmlhttp.send();
}
function ResetIndex(){
	var SelectedTable = document.getElementById("PickTable");
	var sName = SelectedTable.value;
	var xmlhttp;
	var str = "ResetIndex";
	var idName;
	
	switch(sName){
		case "post":
			idName="id_post";
			break;
		case "user":
			idName="id_user";
			break;
		case "comment":
			idName="id_comment";
			break;
		case "moderator":
			idName="id_moderator";
			break;
		case "history":
			idName="id_history";
			break;
		case "relation":
			idName="id_relation";
			break;
		default:
			idName="id";
			break;
	}
	if (window.XMLHttpRequest){
    	// code for IE7+, Firefox, Chrome, Opera, Safari
    	xmlhttp=new XMLHttpRequest();
	}else{
    	// code for IE6, IE5
    	xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
	}
		xmlhttp.onreadystatechange = function() {
    	if (this.readyState == 4 && this.status == 200) {
    	}
	};
	xmlhttp.open("GET","AjaxAdminConversationRoom.php?Action="+str+"&TableName="+sName+"&IndexName="+idName,true);
	xmlhttp.send();
}
function OnChangeHandler(idConcerned){
	setCookie("Active",true,3);
	switch(idConcerned){
		case "PickTable":
			FetchTable();
			UpdateUI("PickOrder");
			break;
		case "ShowTheCorrespondingMenue":
			var Action = document.getElementById("AdminOperationElements").selectedIndex;
			if(Action==0){
				ModifyMenue.style = "display:none;";
				RemoveMenue.style = "display:none;";
			}else if(Action==1){
				ModifyMenue.style = "display:none;";
				RemoveMenue.style = "";
			}else if(Action==2){
				ModifyMenue.style = "";
				RemoveMenue.style = "display:none;";
			}
			break;
		default :
			break;
	}
}
function onClickHandler(idConcerned){
	setCookie("Active",true,3);
	switch(idConcerned){
		case "ConfirmedTableAction":
			var Action = document.getElementById("AdminOperationTable").selectedIndex;
			if(Action==1){
				ResetIndex();
			}else if(Action==2){
				EmptyTable();
			}
			FetchTable();
			break;
		case "RemoveSelectedItem":
			RemoveItems();
			FetchTable();
			break;
		case "ModifiedSelectedItem":
			EditItems();
			FetchTable();
			break;
		case "Menue":
			document.getElementById("Menue").style.width="250px";
			break;
		case "closebtn":
			document.getElementById("Menue").style.width="0px";
			break;
		case "Diconnect":
			DeleteAllCookie();
			break;
		default :
          setCookie("Active",window.location.href,1);
          break;
	}
}
function EditItems(){
	var sElemnetLine;
	var idColValue;
	var sID;
	var a_Selected = document.getElementsByClassName("selected");
	var SelectedTable = document.getElementById("PickTable");
	var SelectedVariable = document.getElementById("TestingCol2");
	var sInput = document.getElementById("sInput");

	var NewValue = sInput.value;
	var sVarName = SelectedVariable.value;
	var sName = SelectedTable.value;
	switch(sName){
		case "post":
			idName="id_post";
			break;
		case "user":
			idName="id_user";
			break;
		case "comment":
			idName="id_comment";
			break;
		case "moderator":
			idName="id_moderator";
			break;
		case "history":
			idName="id_history";
			break;
		case "relation":
			idName="id_relation";
			break;
		default:
			idName="id";
			break;
	}


	for(var iIndexR=0;iIndexR<a_Selected.length;iIndexR++){
		sID = a_Selected[iIndexR].getAttribute('id');
		sElemnetLine=(sID.split('&')[0]).split("=")[1];
		idColValue=document.getElementById("Line="+sElemnetLine+"&Col="+idName).innerHTML;
		EditElement(idName,idColValue,sVarName,NewValue);
	}
}
function EditElement(idName,idElement,idConcernedCol,idNewValue){
	var SelectedTable = document.getElementById("PickTable");
	var xmlhttp;
	var str = "EditElement";
	var sName = SelectedTable.value;

	if (window.XMLHttpRequest){
    	// code for IE7+, Firefox, Chrome, Opera, Safari
    	xmlhttp=new XMLHttpRequest();
	}else{
    	// code for IE6, IE5
    	xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
	}
		xmlhttp.onreadystatechange = function() {
    	if (this.readyState == 4 && this.status == 200) {
    	}
	};
	xmlhttp.open("GET","AjaxAdminConversationRoom.php?Action="+str+"&TableName="+sName+"&IndexName="+idName+"&IDItem="+idElement+"&ConcernedCol="+idConcernedCol+"&NewValue="+idNewValue,true);
	xmlhttp.send();
}
function RemoveItems(){
	var sElemnetLine;
	var idColValue;
	var sID;
	var a_Selected = document.getElementsByClassName("selected");
	var SelectedTable = document.getElementById("PickTable");
	var sName = SelectedTable.value;
	switch(sName){
		case "post":
			idName="id_post";
			break;
		case "user":
			idName="id_user";
			break;
		case "comment":
			idName="id_comment";
			break;
		case "moderator":
			idName="id_moderator";
			break;
		case "history":
			idName="id_history";
			break;
		case "relation":
			idName="id_relation";
			break;
		default:
			idName="id";
			break;
	}

	for(var iIndexR=0;iIndexR<a_Selected.length;iIndexR++){
		sID = a_Selected[iIndexR].getAttribute('id');
		sElemnetLine=(sID.split('&')[0]).split("=")[1];
		idColValue=document.getElementById("Line="+sElemnetLine+"&Col="+idName).innerHTML;
		RemoveElement(idName,idColValue);
	}
}
function RemoveElement(idName,idElement){
	var SelectedTable = document.getElementById("PickTable");

	var xmlhttp;
	var str = "RemoveItem";
	var sName = SelectedTable.value;
	if (window.XMLHttpRequest){
    	// code for IE7+, Firefox, Chrome, Opera, Safari
    	xmlhttp=new XMLHttpRequest();
	}else{
    	// code for IE6, IE5
    	xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
	}
		xmlhttp.onreadystatechange = function() {
    	if (this.readyState == 4 && this.status == 200) {
    	}
	};
	xmlhttp.open("GET","AjaxAdminConversationRoom.php?Action="+str+"&TableName="+sName+"&IndexName="+idName+"&IDItem="+idElement,true);
	xmlhttp.send();
}
function LookupTable(){
	var bReset;
	var Column;
	var sLookup = document.getElementById("LookupValue").value;
	var ColConcerned = document.getElementById("TestingCol").selectedIndex-1;
	if(ColConcerned==-1){
		bReset = true;
	}else{
		bReset = false;
		Column= document.getElementById("Option"+ColConcerned).value;
	}
	var NbRow = (document.getElementsByTagName("tr")).length-1;

	for(var iIndexR = 0;iIndexR<NbRow;iIndexR++){
		var line = document.getElementById("Line"+iIndexR);
		if(bReset){
			line.style="";
		}else{
			var element = document.getElementById("Line="+iIndexR+"&Col="+Column);
			var bChecked = document.getElementById("Line="+iIndexR+"&Col=Checkbox").checked;
			if(element.innerHTML==sLookup){
				line.style="";
			}else{
				line.style="display:none;";
				if(bChecked){
					document.getElementById("Line="+iIndexR+"&Col=Checkbox").checked=false;
					UpdataClasses("Line="+iIndexR+"&Col=Checkbox");
				}
			}
		}
	}
}
function UpdataClasses(element,mode){
	var element = document.getElementById(element);

	var sClassFinal;

	var bFound;

	var ClassContent = element.getAttribute("class");

	var a_sClassContent = ClassContent.split(" ");

	sClassFinal="";
	bFound=false;
	for(var iElement in a_sClassContent){
		if(a_sClassContent[iElement]!="selected"){
			sClassFinal+=a_sClassContent[iElement]+" ";
		}else{
			bFound=true;
		}
	}
	if(mode=="add"){
		sClassFinal+="selected";
	}else{
		sClassFinal=sClassFinal.substring(0,sClassFinal.length-1);
	}
	
	element.setAttribute("class",sClassFinal);
}
function SelectElement(element){
	var element = document.getElementById(element);

	var sClassFinal;

	var bFound;

	var ClassContent = element.getAttribute("class");

	var a_sClassContent = ClassContent.split(" ");

	sClassFinal="";
	bFound=false;
	for(var iElement in a_sClassContent){
		if(a_sClassContent[iElement]!="selected"){
			sClassFinal+=a_sClassContent[iElement]+" ";
		}else{
			bFound=true;
		}
	}
	if(!bFound){
		sClassFinal+="selected";
	}else{
		sClassFinal=sClassFinal.substring(0, sClassFinal.length-1);
	}
	
	element.setAttribute("class",sClassFinal);

}
function FetchTable(){
	var SelectedTable = document.getElementById("PickTable");

	var xmlhttp;
	var str = "FetchTable";
	var sName = SelectedTable.value;

	if (window.XMLHttpRequest){
    	// code for IE7+, Firefox, Chrome, Opera, Safari
    	xmlhttp=new XMLHttpRequest();
	}else{
    	// code for IE6, IE5
    	xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
	}
		xmlhttp.onreadystatechange = function() {
    	if (this.readyState == 4 && this.status == 200) {
    		BuildTable(this.responseText,sName);
    	}
	};
	xmlhttp.open("GET","AjaxAdminConversationRoom.php?Action="+str+"&TableName="+sName,true);
	xmlhttp.send();
}
function UpdateUI(Mode){
	if(Mode=="PickOrder"){
		ActionOnCertainElement.style="display:flex;";
		ActionOnTheTableInGeneral.style="display:flex;";
	}
}