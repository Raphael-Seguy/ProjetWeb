<?php
require_once("connexion_pdo.php");
$dbh = null;
session_start();
if(isset($_SESSION['pseudo'])&&$_SESSION['pseudo']!=""){
	//$dbh=ConnectToDB('localhost','bd_website','Raphael','123456789');
	$dbh = ConnectTODB('localhost','projetweb','user','imtheuser');
	if(isset($_REQUEST["Action"])){
		if($_REQUEST["Action"]=="Like"){
			$Query = $dbh->prepare("SELECT * FROM history WHERE `id_user` = :idUser AND `id_post` = :idPost");
			$Query->bindParam(':idPost',$_GET['IDPost'],PDO::PARAM_INT);
			$Query->bindParam(':idUser',$_GET['IDUser'],PDO::PARAM_INT);
			try{
				$Query->execute();
				$result = $Query->fetch(PDO::FETCH_ASSOC);
				if($result['liked']==0){
					$Liked=1;
				}else{
					$Liked=0;
				}
				$Query = $dbh->prepare("UPDATE `history` SET `liked`=:Liked WHERE `id_user` = :idUser AND `id_post` = :idPost");
				$Query->bindParam(':idPost',$_GET['IDPost'],PDO::PARAM_INT);
				$Query->bindParam(':idUser',$_GET['IDUser'],PDO::PARAM_INT);
				$Query->bindParam(':Liked',$Liked,PDO::PARAM_INT);
				try{
					if($Query->execute()){
						if($Liked==1){
							echo "background-color:red;";
						}else{
							echo "background-color:none;";
						}
						
					}
				}catch(PDOException $e){
					echo "Delete Failed: ".$e->getMessage();
				}
			}catch(PDOException $e){
				echo "Action Failed: ".$e->getMessage();
			}
		}else if($_REQUEST["Action"]=="Follow"){
			$Query = $dbh->prepare("SELECT * FROM relation WHERE `id_usersource`=:idUserA AND `id_userinput`=:idUserB");
			$Query->bindParam(':idUserA',$_GET['IDUserA'],PDO::PARAM_INT);
			$Query->bindParam(':idUserB',$_GET['IDUserB'],PDO::PARAM_INT);
			try{
				$Query->execute();
				$NbCount=$Query->rowCount();
				if($NbCount>0){
					$Query = $dbh->prepare("DELETE FROM relation WHERE (`id_usersource`=:idUserA AND `id_userinput`=:idUserB)");
					$Query->bindParam(':idUserA',$_GET['IDUserA'],PDO::PARAM_INT);
					$Query->bindParam(':idUserB',$_GET['IDUserB'],PDO::PARAM_INT);
					try{
						if($Query->execute()){
							echo "background-color:none;#fa fa-user-plus";
						}
					}catch(PDOException $e){
						echo "Delete Failed: ".$e->getMessage();
					}
				}else{
					$Query = $dbh->prepare("INSERT INTO `relation` (`id_usersource`,`id_userinput`) Values (:idUserA,:idUserB)");
					$Query->bindParam(':idUserA',$_GET['IDUserA'],PDO::PARAM_INT);
					$Query->bindParam(':idUserB',$_GET['IDUserB'],PDO::PARAM_INT);
					try{
						if($Query->execute()){
							echo "background-color:pink;#fa fa-users";
						}
					}catch(PDOException $e){
						echo "Insertion Failed: ".$e->getMessage();
					}
				}
			}catch(PDOException $e){
				echo "Action Failed: ".$e->getMessage();
			}
		}else if($_REQUEST["Action"]=="Comment"){
			$bModerateur = false;
			$Query2 = $dbh->prepare("SELECT Count(*) as NbCount FROM (SELECT id_user,id_post FROM moderator UNION SELECT id_user,id_post FROM post) AS temp WHERE id_user=:idUser AND id_post=:idPost");
			$Query2->bindParam(":idPost",$_GET['IDPost'],PDO::PARAM_INT);
			$Query2->bindParam(":idUser",$_GET['IDUser'],PDO::PARAM_INT);
			try{
				if(!$Query2->execute()){
					echo "There have been an error<br>";
				}else{
					$result2=$Query2->fetch(PDO::FETCH_ASSOC);
					if($result2["NbCount"]>0){
						$bModerateur=true;
					}
				}
			}catch(PDOException $e){
				echo "Lookup error";
			}
			$bOwner = false;
			$Query = $dbh->prepare("SELECT * FROM comment WHERE (id_post=:idPost);");
			$Query->bindParam(":idPost",$_GET['IDPost'],PDO::PARAM_INT);
			try {
				$Query->execute();
				$Comments="";
				$Comment="";
				while(($result = $Query->fetch(PDO::FETCH_ASSOC))!=null){
					if($result['id_user']==$_GET['IDUser']){
						$bOwner=true;
					}else{
						$bOwner = false;
					}
					$Comment.='<div class="container square CommentContainer">';
					$Comment.='<table class="CommentLayout">';
					$Comment.='<tr class="CommentMain"><td class="CommentContent RightBorder"><p>'.$result['content'].'</p></td>';
					if($bModerateur && !$bOwner){
						$Comment.='<td class="CommentExtraAction"><p><button class="btn btnRemove" onclick=\'OnClickHandler2("RemoveComment",'.$result['id_comment'].')\'>Remove</button></p></td></tr>';
					}else if($bOwner){
						$Comment.='<td class="CommentExtraAction"><button class="btn btnRemove" onclick=\'OnClickHandler2("RemoveComment",'.$result['id_comment'].')\'>Remove</button> <button class="btn btnEdit"  onclick=\'OnClickHandler2("EditComment",'.$result['id_comment'].')\'>Edit</button></td></tr>';
					}else{
						$Comment.="</tr>";
					}
					$Comment.="<tr><td class='RightBorder'><h6>-".GetUserPseudo($dbh,$result['id_user'])."</h6></td></tr>";
					$Comment.="</table>";
					$Comment.="</div>";
					$Comments.=$Comment;
					$Comment="";
				}
				echo $Comments;
			} catch (PDOException $e) {
				$e->getMessage();
			}
		}else if($_REQUEST["Action"]=="AddComment"){
			$Query = $dbh->prepare("INSERT INTO `comment` (`id_user`, `id_post`, `content`) VALUES (:idUser, :idPost, :Content)");
			$Query->bindParam(":idUser",$_GET["IDUser"],PDO::PARAM_INT);
			$Query->bindParam(":idPost",$_GET["IDPost"],PDO::PARAM_INT);
			$Query->bindParam(":Content",$_GET["Content"],PDO::PARAM_STR,10000);
			try{
				if(!$Query->execute()){
					echo $_GET['Content'];
				}else{
					echo "Worked";
				}
			}catch(PDOException $e){
				$e->getMessage();	
			}
		}else if($_REQUEST["Action"]=="GetCommentContent"){
			$Query = $dbh->prepare("SELECT content FROM `comment` WHERE id_comment=:idComment");
			$Query->bindParam(":idComment",$_GET['IDComment']);
			try{
				if(!$Query->execute()){
					echo "Erreur lors de l'import";
				}else{
					$result=$Query->fetch(PDO::FETCH_ASSOC);
					echo $result["content"];
				}
			}catch(PDOException $e){
				$e->getMessage();	
			}
		}else if($_REQUEST["Action"]=="ModifyComment"){
			$Query = $dbh->prepare("UPDATE `comment` SET `content`=:Content WHERE `id_comment`=:idComment");
			$Query->bindParam(":Content",$_GET['Content'],PDO::PARAM_STR,10000);
			$Query->bindParam(":idComment",$_GET["IDComment"],PDO::PARAM_INT);
			try{
				if(!$Query->execute()){
					echo "Erreur lors de l'import";
				}else{
					echo "Worked";
				}
			}catch(PDOException $e){
				$e->getMessage();	
			}
		}else if($_REQUEST["Action"]=="RemoveComment"){
			$Query = $dbh->prepare("DELETE FROM `comment` WHERE `id_comment` = :idComment");
			$Query->bindParam(":idComment",$_GET["IDComment"],PDO::PARAM_INT);
			try{
				if(!$Query->execute()){
					echo "Erreur lors de l'import";
				}else{
					echo "Worked";
				}
			}catch(PDOException $e){
				$e->getMessage();	
			}
		}else if($_REQUEST['Action']=="GetPost"){
			$Query = $dbh->prepare('SELECT * FROM `post` WHERE `post`.`id_post`=:idPost');
			$Query->bindParam(":idPost",$_GET['IDPost']);
			if(!$Query->execute()){
				$e->getMessage();
			}else{
				$result=$Query->fetch(PDO::FETCH_ASSOC);
				echo $result['id_post']."\\".$result["id_user"]."\\".$result["latitude"]."\\".$result['longitude'].'\\'.$result['photo']."\\".(GetUserPseudo($dbh,$result['id_user'])."\\".(GetLike($dbh,$result['id_post']))."\\".(GetVues($dbh,$result['id_post'])));
			}
		}else if($_REQUEST["Action"]=="RegisterVisited"){
			$Query = $dbh->prepare("SELECT `id_history` FROM `history` WHERE `id_post`=:idPost AND `id_user`=:idUser");
			$Query->bindParam(":idUser",$_GET["IDUser"],PDO::PARAM_INT);
			$Query->bindParam(":idPost",$_GET["IDPost"],PDO::PARAM_INT);
			try{
				if(!$Query->execute()){
					echo "Erreur : Lookup failed";
				}else{
					$result=$Query->rowCount();
					if($result<1){
						$Query = $dbh->prepare("INSERT INTO `history` (`id_user`, `id_post`) VALUES (:idUser, :idPost)");
						$Query->bindParam(":idUser",$_GET["IDUser"],PDO::PARAM_INT);
						$Query->bindParam(":idPost",$_GET["IDPost"],PDO::PARAM_INT);
					
						if(!$Query->execute()){
							echo "Error";
						}else{
							echo "Worked";
						}
					}
				}
				
			}catch(PDOException $e){
				$e->getMessage();	
			}
		}else if ($_REQUEST["Action"]=="GetPostPos") {
			$Query = $dbh->prepare("SELECT `post`.`id_post`,`post`.`latitude`,`post`.`longitude` FROM `post` WHERE 1 ");
			try{
				if(!$Query->execute()){
					echo "Erreur : Lookup Failed";
				}else{
					$sResponse="";
					while (($result=$Query->fetch(PDO::FETCH_ASSOC))!=null) {
						$sResponse.=$result['id_post']."#".$result['latitude']."#".$result['longitude']."/";
					}
					$sResponse=substr($sResponse, 0,mb_strlen($sResponse)-1);
					echo $sResponse;
				}
			}catch(PDOException $e){
				$e->gettMessage();
			}
		}else if($_REQUEST["Action"]=="CheckUserRelatedInformation"){
			$Query1=$dbh->prepare("SELECT temp1.`id_history` as liked FROM (SELECT `history`.`id_history` FROM `history` WHERE `history`.`id_user`=:idUserA AND `history`.`id_post`=:idPost AND `history`.`liked`=1) as temp1");
			$Query1->bindParam(":idUserA",$_GET["IDUserA"],PDO::PARAM_INT);
			$Query1->bindParam(":idPost",$_GET["IDPost"],PDO::PARAM_INT);
			$Query2 = $dbh->prepare('SELECT temp2.`id_relation` as followed FROM (SELECT `relation`.`id_relation` FROM `relation` WHERE `relation`.`id_usersource`=:idUserA AND `relation`.`id_userinput`=:idUserB) as temp2');
			$Query2->bindParam(":idUserA",$_GET["IDUserA"],PDO::PARAM_INT);
			$Query2->bindParam(":idUserB",$_GET["IDUserB"],PDO::PARAM_INT);
			try{
				if(!$Query1->execute()){
					echo "Erreur : Lookup failed";
					$responseLiked="error";
				}else{
					$result = $Query1->fetch(PDO::FETCH_ASSOC);
					if($result['liked']!=0){
						$responseLiked="background-color:red;";
					}else{
						$responseLiked="";
					}
				}
				if(!$Query2->execute()){
					echo "Erreur : Lookup Failed";
					$responseFollowed = "error";
				}else{
					$result = $Query2->fetch(PDO::FETCH_ASSOC);
					if($result['followed']!=0){
						$responseFollowed="background-color:pink;";
					}else{
						$responseFollowed="";
					}
				}
				$response = $responseFollowed."/".$responseLiked;
				echo $response;
			}catch(PDOException $e){
				$e->getMessage();
			}
		}else if($_REQUEST["Action"]=="PHPCookieToJavascript"){
			echo $_SESSION[$_REQUEST['sName']];
		}
	}
}
function GetVues($dbh,$ID){
	$Query = $dbh->prepare("SELECT Count(*) AS NBVues FROM `history` WHERE `history`.`id_post`=:idPost");
	$Query->bindParam(":idPost",$ID,PDO::PARAM_INT);
	if(!$Query->execute()){
		return -1;
	}else{
		$result=$Query->fetch(PDO::FETCH_ASSOC);
		return $result['NBVues'];
	}
}
function GetLike($dbh,$ID){
	$Query = $dbh->prepare("SELECT Count(*) AS NBLikes FROM `history` WHERE `history`.`id_post`=:idPost AND `history`.`liked`=1 " );
	$Query->bindParam(":idPost",$ID,PDO::PARAM_INT);
	if(!$Query->execute()){
		return -1;
	}else{
		$result=$Query->fetch(PDO::FETCH_ASSOC);
		return $result['NBLikes'];
	}
}
function GetUserPseudo($dbh,$ID){
	$Query = $dbh->prepare("SELECT pseudo FROM user WHERE id_user = :idUser");
	$Query->bindParam(':idUser',$ID,PDO::PARAM_INT);

	if(!$Query->execute()){
		echo "Error";
	}else{
		$name=$Query->fetch(PDO::FETCH_ASSOC);
		return $name['pseudo'];
	}
}
?>
