<?php
	require_once("connexion_pdo.php");
	session_start();
	$dbh = null;
	if(isset($_SESSION['pseudo'])&&$_SESSION['pseudo']!=""){
		$dbh=ConnectToDB('localhost','bd_website','Raphael','123456789');
	}else{
		header('Location: Connection.php');
	}
?>
<!DOCTYPE html>
<html>
<head>
	<title>Full Map</title>
	<meta charset="utf-8">
	<link rel="stylesheet" type="text/css" href="bootstrap-css/Index.css">
	<link rel="stylesheet" href="fontawesome-free-web/css/font-awesome.min.css">
	<link rel="stylesheet" type="text/css" href="./CSS/FullMap.css">
	<link rel="stylesheet" type="text/css" href="bootstrap-css/bootstrap.min.css">
	<script src="https://kit.fontawesome.com/4e1c428a1b.js" crossorigin="anonymous"></script>
	<script src="AddOn/leaflet.js"></script>
	<script src="./JS/Cookie_Organisation_Script.js"></script>
	<link rel="stylesheet" href="AddOn/leaflet.css" />
</head>
<body onload="initialise();">
	<nav class="navbar navbar-inverse navbar bg-dark navbar-dark"><!--navbar bg-dark navbar-dark-->
	  <div class="container-fluid">
	    <div class="navbar-header">
	      <a class="navbar-brand" href="#"><h1>QuickPic</h1></a>
	    </div>

	     
	      <!--<div class="input-group-btn">
	      <button class="btn btn-default" type="submit">
	       <i class="fas fa-search"></i>
	      </button>-->

	    <form class="formulaire" action="/action_page.php"><!--navbar-form navbar-left-->
	      <div class="form-group">
	           <div class="p-2 bd-highlight right">
	        <ul>
	      <div class="d-flex justify-content-end bd-highlight mb-3 flex">
	    <div class="p-2 bd-highlight settings"><button type="button" class="btn" onclick='onClickHandler("Menue")'><i class="fas fa-bars"></i></button></div>
	    <div class="p-2 bd-highlight users"><a class="aref" href="TempProfilePage.html"><li class="btn"><i class="fas fa-user-circle"></i></li></a></div>
	      </ul>
	  </div>

	    </div>
	    </form>
	  </div>
	</nav>
	<div id="Map" class="Map"></div>
	<div id="Menue" class="sidenav">
  		<a href="javascript:void(0)" class="closebtn" id="closebtn" onclick='onClickHandler("closebtn")'>&times;</a>
  		<?php if(isset($_SESSION['level']) && $_SESSION['level']==1){echo '<a href="AdminPage.php" onclick="onClickHandler("Acted")">Admin zone</a>';}?>
  		<a href="Home_WebPage.php" onclick='onClickHandler("Acted")'>See Post</a>
  		<a href="Deconnection.php" onclick='onClickHandler("Diconnect")'>Disconnect</a>
	</div>
	<script src="./JS/FullMap.js"></script>
</body>
</html>