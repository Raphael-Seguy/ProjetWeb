<?php 
  if(isset($_POST)){
    if(isset($_POST['slogin'])&&isset($_POST['sPass'])){
      $sLogin = $_POST['slogin'];
      $sPass = $_POST['sPass'];
      if($slogin.stripos("@")!=FALSE){
        $Query="SELECT `LEVEL`,`PSEUDO`,`PASSWORD` FROM `user` WHERE MAIL=:Login";
        $resultat=$dbh->prepare($Query);
        $resultat->bindParam(':Login',$sLogin,PDO::PARAM_STR,100);
        if(!$resultat->execute()){
          $sError = 'Probleme de requête!!';
        }else{
          $iNbResultat = $resultat->rowCount();
          if($iNbResultat>1){
            $sError = 'Probleme de base de Données dupliquat!!!';
          }elseif ($iNbResultat==1) {
            $row = $resultat->fetch(PDO::FETCH_ASSOC);
            $hshPass=$row['PASSWORD'];
            if(password_verify($sPass, $hshPass)){
              $_SESSION['PSEUDO'] = $row['PSEUDO'];
              $_SESSION['LEVEL'] = $row['LEVEL'];
            }else{
              $sError = 'Probleme with your Username/password';
            }
          }else{
            $sError = 'Probleme with your Username/password';
          }
        }
      }else{
        $Query="SELECT `LEVEL`,`PSEUDO`,`PASSWORD` FROM `user` WHERE PSEUDO=:Login";
        $resultat=$dbh->prepare($Query);
        $resultat->bindParam(':Login',$sLogin,PDO::PARAM_STR,100);
        if(!$resultat->execute()){
          $sError = 'Probleme de requête!!';
        }else{
          $iNbResultat = $resultat->rowCount();
          if($iNbResultat>1){
            $sError = 'Probleme de base de Données dupliquat!!!';
          }elseif ($iNbResultat==1) {
            $row = $resultat->fetch(PDO::FETCH_ASSOC);
            $hshPass=$row['PASSWORD'];
            if(password_verify($sPass, $hshPass)){
              $_SESSION['PSEUDO'] = $row['PSEUDO'];
              $_SESSION['LEVEL'] = $row['LEVEL'];
            }else{
              $sError = 'Probleme with your Username/password';
            }
          }else{
            $sError = 'Probleme with your Username/password';
          }
        }
      }
    }
  }
?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<link rel="stylesheet" type="text/css" href="bootstrap-css/bootstrap.min.css"><!--classe déjà faite-->
	<link rel="stylesheet" type="text/css" href="bootstrap-css/Home.css">
	<script src="https://kit.fontawesome.com/4e1c428a1b.js" crossorigin="anonymous"></script>
	<title>Home</title>
</head>
<body class="text-center">
   
   <div class="container square">

   	<form class="form-login" method="POST" action="">
   		
   		<h1 class="h3 mb-3 font-weight-normal">Connexion</h1>

   		<div class="mail"><input type="text" name="slogin" id="sInputLogin" class="form-control" placeholder=" Adresse email ou Pseudo " required autofocus></div>
   		<div class="pw"><input type="password" name="sPass" id="sInputPassword" class="form-control" placeholder=" Mot de passe " required></div>
  		<div class="checkbox mb-3">
      <input type="checkbox" name="bRememberMe" value="remember-me"> Se souvenir de moi
  </div>
   
  <div><button type="submit">Sign in</button></div>

  <div class="restore-pw"><a href="" name="restore-pw">Mot de passe oublié?</a></div>

  </div>

  <div class="container new-users">Vous n'avez pas de compte?<br><a href="SignIn.html">Inscrivez-vous!</a></div>
  
  
  <!--&copy;-->
   	</form>

   	<p class="mt-5 mb-3 text-muted">Projet Web 2019-2020</p>
   
  

</body>

</html>
