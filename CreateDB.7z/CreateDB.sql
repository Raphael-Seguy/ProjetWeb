-- phpMyAdmin SQL Dump
-- version 4.9.1
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1
-- Généré le :  mar. 29 oct. 2019 à 20:30
-- Version du serveur :  10.4.8-MariaDB
-- Version de PHP :  7.3.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données :  `projetweb`
--

-- --------------------------------------------------------

--
-- Structure de la table `users`
--
CREATE TABLE `setting` (
	`id_setting` SMALLINT(11) PRIMARY KEY  NOT NULL,
	`background_color` VARCHAR(70) NOT NULL,
	`border_color` VARCHAR(70) NOT NULL,
	`font_color` VARCHAR(70) NOT NULL  
)ENGINE=INNODB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
INSERT INTO `setting` VALUES (1,"#ffffff","#a9a9a9","#000000");
CREATE TABLE `user` (
  `id_user` int(11) PRIMARY KEY  NOT NULL,
  `email` varchar(255) COLLATE utf8_bin NOT NULL,
  `pseudo` varchar(255) COLLATE utf8_bin NOT NULL,
  `age` int(11) NOT NULL,
  `password` varchar(25) COLLATE utf8_bin NOT NULL,
  `level` SMALLINT(11) DEFAULT 0 NOT NULL,
  `id_setting` SMALLINT DEFAULT 1 NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
ALTER TABLE `user` ADD CONSTRAINT fk_IDSETTING FOREIGN KEY(`id_setting`) REFERENCES `setting`(`id_setting`);
INSERT INTO `users` (`id_users`, `email`, `pseudo`, `age`, `password`,`level`,`id_setting`) VALUES
(1, 'anguyen.rick@gmail.com', 'dd', 12, '$2y$10$dKSWAiGg0Kpi7gzAwf',0,1),
(2, 'dd@dd', 'dd', 12, '$2y$10$blvWMnyvE2XJtTJcXG',0,1),
(3, 'EE@OO', 'dd', 0, '$2y$10$xGqOAI0zND4PEBviFw',0,1);
CREATE TABLE `photo`(
	`id_photo` SMALLINT(11) PRIMARY KEY NOT NULL,
	`source` VARCHAR(10000) NOT NULL,
	`longitude` decimal NOT NULL,
	`latitude` decimal not null
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
CREATE TABLE `post`(
	`id_post` SMALLINT(11) PRIMARY KEY NOT null,
	`id_user` int(11),
	`id_photo` int(11),
	FOREIGN KEY ('id_user')
		REFERENCES user('id_user')
		ON DELETE CASCADE,
	FOREIGN KEY ('id_photo')
		REFERENCES photo('id_photo')
		ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
CREATE TABLE `comment`(
	`id_user` SMALLINT(40),
	`id_post` SMALLINT(11),
	FOREIGN KEY ('id_user')
		REFERENCES user(`id_user`)
		ON DELETE CASCADE,
	FOREIGN KEY ('id_post')
		REFERENCES post(`id_post`)
		ON DELETE CASCADE,
	PRIMARY KEY(`id_user`,`id_photo`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;