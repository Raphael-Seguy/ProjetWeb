-- phpMyAdmin SQL Dump
-- version 4.9.1
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1
-- Généré le :  mar. 29 oct. 2019 à 20:30
-- Version du serveur :  10.4.8-MariaDB
-- Version de PHP :  7.3.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données :  `projetweb`
--

-- --------------------------------------------------------

--
-- Structure de la table `user`
--
CREATE TABLE `user` (
  `id_user` int(11) PRIMARY KEY AUTO_INCREMENT NOT NULL,
  `email` varchar(255) COLLATE utf8_bin NOT NULL,
  `pseudo` varchar(255) COLLATE utf8_bin NOT NULL,
  `age` int(11) NOT NULL,
  `photo` varchar(255) COLLATE utf8_bin,
  `password` varchar(255) COLLATE utf8_bin NOT NULL,
  `level` SMALLINT(11) DEFAULT 0 NOT NULL,
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Structure de la table `relation`
--

CREATE TABLE `relation`(
	`id_relation` SMALLINT(11) PRIMARY KEY AUTO_INCREMENT NOT NULL,
	`id_usersource` int(11) Not null,
	`id_userinput` int(11) not Null,
	`relation_level` int(11) DEFAULT 1 not null,
	FOREIGN KEY (`id_usersource`)
		REFERENCES user(`id_user`)
		On DELETE CASCADE ON Update CASCADE,
	FOREIGN KEY(`id_userinput`)
		REFERENCES user(`id_user`)
		On DELETE CASCADE ON Update CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
-- --------------------------------------------------------

--
-- Structure de la table `post`
--

CREATE TABLE `post`(
	`id_post` SMALLINT(11) PRIMARY KEY AUTO_INCREMENT NOT null,
	`id_user` int(11),
	`latitude` float(11),
	`longitude` float(11),
	`photo` varchar(255) COLLATE utf8_bin,
	FOREIGN KEY (`id_user`)
		REFERENCES user(`id_user`)
		ON DELETE CASCADE ON Update CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- --------------------------------------------------------

--
-- Structure de la table `comment`
--
CREATE TABLE `comment`(
	`id_comment` SMALLINT(11) PRIMARY KEY AUTO_INCREMENT NOT null,
	`id_user` Int(11),
	`id_post` SMALLINT(11),
	`content` longtext COLLATE utf8_bin,
	FOREIGN KEY (`id_user`)
		REFERENCES user(`id_user`)
		ON DELETE CASCADE ON Update CASCADE,
	FOREIGN KEY (`id_post`)
		REFERENCES post(`id_post`)
		ON DELETE CASCADE ON Update CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
-- --------------------------------------------------------

--
-- Structure de la table `moderator`
--

CREATE TABLE `moderator`(
	`id_moderator` SMALLINT(11) PRIMARY KEY AUTO_INCREMENT NOT null,
	`id_user` Int(11),
	`id_post` SMALLINT(11),
	FOREIGN KEY (`id_user`)
		REFERENCES user(`id_user`)
		ON DELETE CASCADE ON Update CASCADE,
	FOREIGN KEY (`id_post`)
		REFERENCES post(`id_post`)
		ON DELETE CASCADE ON Update CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
-- --------------------------------------------------------

--
-- Structure de la table `history`
--

CREATE TABLE `history`(
	`id_history` SMALLINT(11) PRIMARY KEY AUTO_INCREMENT NOT null,
	`id_user` Int(11),
	`id_post` SMALLINT(11),
	`liked` tinyint(1) Default 0,
	FOREIGN KEY (`id_user`)
		REFERENCES user(`id_user`)
		ON DELETE CASCADE ON Update CASCADE,
	FOREIGN KEY (`id_post`)
		REFERENCES post(`id_post`)
		ON DELETE CASCADE ON Update CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
-- --------------------------------------------------------
