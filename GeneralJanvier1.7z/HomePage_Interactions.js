// Get the modal
// Get the <span> element that closes the modal
setInterval(Check, 1000);
var marker;
var mymap = L.map('Zemap').setView([0,0], 13);
L.tileLayer('https://api.tiles.mapbox.com/v4/{id}/{z}/{x}/{y}.png?access_token={accessToken}', {
		attribution: 'Map data &copy; <a href="https://www.openstreetmap.org/">OpenStreetMap</a> contributors, <a href="https://creativecommons.org/licenses/by-sa/2.0/">CC-BY-SA</a>, Imagery © <a href="https://www.mapbox.com/">Mapbox</a>',
		maxZoom: 18,
		id: 'mapbox.streets',
		accessToken: 'pk.eyJ1Ijoic2FwaG9nYW1lcyIsImEiOiJjazF5emp1dDQwbWNwM2RwY29kMDJ0Y2cwIn0.JuCgfRb9xFq83jdbh9UP8g'
}).addTo(mymap);

var span = document.getElementsByClassName("close")[0];

//Imported Value
var bRememberMe;

function SetRemenberMe(Value){
	bRememberMe = Value;
}
function GetRemember(){
	return bRememberMe;
}
//input Listener
document.onkeydown = function(){
	let evtobj = window.event? event : e
	let console = document.getElementById("SecretModal");
	if(evtobj.altKey && evtobj.keyCode===120){
		console.style.display = "block";
	}
}
function initialise(){
	SetRememberOption();
	InitialiseJavascriptCookie();
	var idPost = getCookie("PreviousPost");
	if(idPost!=0){
		GetPost(idPost);
	}else{
		GetNextPost();
	}
}
function GetCheat(sElementId){
	sValue = document.getElementById(sElementId).value;
	if(sValue==="pepperoni pizza" || sValue==="mlg" || sValue==="snake"){
		sDirectory = window.location.pathname;
		sDirectory = sDirectory.split("/");
		sDirectory=sDirectory[1];
		window.location.replace(window.location.protocol+'/'+sDirectory+'/RoomCH.php');

	}
}
function InitialiseJavascriptCookie(){
	if(checkCookie("Username")){
		setCookie("CurrentPage",window.location.href,3);
	}else{
		var xmlhttp;
    	var str = "PHPCookieToJavascript";
    	var Information = "";
    	var sPseudo="";
    	var sName="pseudo";

    	if (window.XMLHttpRequest){
        	// code for IE7+, Firefox, Chrome, Opera, Safari
        	xmlhttp=new XMLHttpRequest();
    	}else{
        	// code for IE6, IE5
        	xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
    	}
   		xmlhttp.onreadystatechange = function() {
        	if (this.readyState == 4 && this.status == 200) {
        		sPseudo=this.responseText;
        		setCookie("Username",sPseudo,3);
        		setCookie("CurrentPage",window.location.href,3);
        		setCookie("PreviousPost",0,3);
        	}
    	};
    	xmlhttp.open("GET","AjaxConversationRoom.php?Action="+str+"&sName="+sName,true);
    	xmlhttp.send();
	}
	
}
function SetRememberOption(){
	var xmlhttp;
	var str = "PHPCookieToJavascript";
	var Information = "";
	var sName="java_cookie";

	if (window.XMLHttpRequest){
    	// code for IE7+, Firefox, Chrome, Opera, Safari
    	xmlhttp=new XMLHttpRequest();
	}else{
    	// code for IE6, IE5
    	xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
	}
		xmlhttp.onreadystatechange = function() {
    	if (this.readyState == 4 && this.status == 200) {
    		SetRemenberMe(this.responseText);
    	}
	};
	xmlhttp.open("GET","AjaxConversationRoom.php?Action="+str+"&sName="+sName,true);
	xmlhttp.send();
}
function RegisterLike(){
	// Create a variable to refer to our request object:
    var xmlhttp;
    var RequestCounter;
    var Action = "PHPCookieToJavascript";
    var Param = "id_user";
    var idUser;
    RequestCounter=0;
    var request = "AjaxConversationRoom.php?Action="+Action+"&sName="+Param;

    if (window.XMLHttpRequest){
        // code for IE7+, Firefox, Chrome, Opera, Safari
        xmlhttp=new XMLHttpRequest();
    }else{
        // code for IE6, IE5
        xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
    }
   	xmlhttp.onreadystatechange = function() {
        if (this.readyState == 4 && this.status == 200) {
        	if(RequestCounter==1){
        		idUser = this.responseText;
        		Action = "Like";
        		var idPost = document.getElementById("currentPost").value;
    			RequestCounter+=1;
        		request = "AjaxConversationRoom.php?Action="+Action+"&IDPost="+idPost+"&IDUser="+idUser;
        		xmlhttp.open("GET",request,true);
    			xmlhttp.send();
        	}else{
        		document.getElementById("Like").style = this.responseText;
                if("background-color:red;"==this.responseText){
                    document.getElementById("NbLike").innerHTML=parseInt(document.getElementById("NbLike").innerHTML)+1;
                }else{
                    document.getElementById("NbLike").innerHTML=parseInt(document.getElementById("NbLike").innerHTML)-1;
                }
        	}
        }
    };
    xmlhttp.open("GET",request,true);
    xmlhttp.send();
    RequestCounter+=1;
}
function RegisterFollow(){
	// Create a variable to refer to our request object:
    var xmlhttp;
    var RequestCounter;
    var Action = "PHPCookieToJavascript";
    var Param = "id_user";
    var idUser;
    RequestCounter=0;
    var request = "AjaxConversationRoom.php?Action="+Action+"&sName="+Param;

    if (window.XMLHttpRequest){
        // code for IE7+, Firefox, Chrome, Opera, Safari
        xmlhttp=new XMLHttpRequest();
    }else{
        // code for IE6, IE5
        xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
    }
   	xmlhttp.onreadystatechange = function() {
        if (this.readyState == 4 && this.status == 200) {
        	if(RequestCounter==1){
        		idUserA = this.responseText;
        		Action = "Follow";
        		var idUserB = document.getElementById("currentAuthor").value;
    			RequestCounter+=1;
        		request = "AjaxConversationRoom.php?Action="+Action+"&IDUserA="+idUserA+"&IDUserB="+idUserB;
        		xmlhttp.open("GET",request,true);
    			xmlhttp.send();
        	}else{
                sResponse = this.responseText;
                a_sResponse = sResponse.split("#");
        		document.getElementById("Follow").style = a_sResponse[0];
                document.getElementById("IconFollow").setAttribute("class",a_sResponse[1]);
        	}
        }
    };
    xmlhttp.open("GET",request,true);
    xmlhttp.send();
    RequestCounter+=1;
}
function AddComment(){
	var xmlhttp;
    var RequestCounter;
    var sContent = CKEDITOR.instances.NewComment.getData();
    sContent = escape(sContent);
    var Action = "PHPCookieToJavascript";
    var Param = "id_user";
    var idUser;
    RequestCounter=0;
    var request = "AjaxConversationRoom.php?Action="+Action+"&sName="+Param;

    if (window.XMLHttpRequest){
        // code for IE7+, Firefox, Chrome, Opera, Safari
        xmlhttp=new XMLHttpRequest();
    }else{
        // code for IE6, IE5
        xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
    }
   	xmlhttp.onreadystatechange = function() {
        if (this.readyState == 4 && this.status == 200) {
        	if(RequestCounter==1){
        		idUser = this.responseText;
        		Action = "AddComment";
        		var idPost = document.getElementById("currentPost").value;
    			RequestCounter+=1;
        		request = "AjaxConversationRoom.php?Action="+Action+"&IDUser="+idUser+"&IDPost="+idPost+"&Content=%20"+sContent;
        		xmlhttp.open("GET",request,true);
    			xmlhttp.send();
        	}else{
        		document.getElementById("Follow").style = this.responseText;
        	}
        }
    };
    xmlhttp.open("GET",request,true);
    xmlhttp.send();
    RequestCounter+=1;
}
function GetCommentContent(idComment){
	var xmlhttp;
    var sAction = "GetCommentContent";
    var Information = "";

    if (window.XMLHttpRequest){
        // code for IE7+, Firefox, Chrome, Opera, Safari
        xmlhttp=new XMLHttpRequest();
    }else{
        // code for IE6, IE5
        xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
    }
   	xmlhttp.onreadystatechange = function() {
        if (this.readyState == 4 && this.status == 200) {
        	CKEDITOR.instances.NewComment.setData(this.responseText);
        }
    };
    xmlhttp.open("GET","AjaxConversationRoom.php?Action="+sAction+"&IDComment="+idComment,true);
    xmlhttp.send();
}
function RemoveComment(idComment){
	var xmlhttp;
    var sAction = "RemoveComment";
    if (window.XMLHttpRequest){
        // code for IE7+, Firefox, Chrome, Opera, Safari
        xmlhttp=new XMLHttpRequest();
    }else{
        // code for IE6, IE5
        xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
    }
   	xmlhttp.onreadystatechange = function() {
        if (this.readyState == 4 && this.status == 200) {
        }
    };
    xmlhttp.open("GET","AjaxConversationRoom.php?Action="+sAction+"&IDComment="+idComment,true);
    xmlhttp.send();
}
function ModifyComment(idComment){
	var xmlhttp;
    var sAction = "ModifyComment";
    var sContent = CKEDITOR.instances.NewComment.getData();
    sContent = escape(sContent);
    if (window.XMLHttpRequest){
        // code for IE7+, Firefox, Chrome, Opera, Safari
        xmlhttp=new XMLHttpRequest();
    }else{
        // code for IE6, IE5
        xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
    }
   	xmlhttp.onreadystatechange = function() {
        if (this.readyState == 4 && this.status == 200) {
        }
    };
    xmlhttp.open("GET","AjaxConversationRoom.php?Action="+sAction+"&IDComment="+idComment+"&Content="+sContent,true);
    xmlhttp.send();
}
function GatherComments(){
	// Create a variable to refer to our request object:

    var xmlhttp;
    var RequestCounter;
    var Action = "PHPCookieToJavascript";
    var Param = "id_user";
    var idUser;
    RequestCounter=0;
    var request = "AjaxConversationRoom.php?Action="+Action+"&sName="+Param;

    if (window.XMLHttpRequest){
        // code for IE7+, Firefox, Chrome, Opera, Safari
        xmlhttp=new XMLHttpRequest();
    }else{
        // code for IE6, IE5
        xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
    }
   	xmlhttp.onreadystatechange = function() {
        if (this.readyState == 4 && this.status == 200) {
        	if(RequestCounter==1){
        		idUser = this.responseText;
        		Action = "Comment";
        		var idPost = document.getElementById("currentPost").value;
    			RequestCounter+=1;
        		request = "AjaxConversationRoom.php?Action="+Action+"&IDUser="+idUser+"&IDPost="+idPost;
        		xmlhttp.open("GET",request,true);
    			xmlhttp.send();
        	}else{
        		document.getElementById("CommentCargo").innerHTML = this.responseText;
        	}
        }
    };
    xmlhttp.open("GET",request,true);
    xmlhttp.send();
    RequestCounter+=1;
}
function GetAValueInCookie(sName){
	var xmlhttp;
    var str = "PHPCookieToJavascript";
    var Information = "";

    if (window.XMLHttpRequest){
        // code for IE7+, Firefox, Chrome, Opera, Safari
        xmlhttp=new XMLHttpRequest();
    }else{
        // code for IE6, IE5
        xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
    }
   	xmlhttp.onreadystatechange = function() {
        if (this.readyState == 4 && this.status == 200) {
        	Information=this.responseText;
        	return Information;
        }
    };
    xmlhttp.open("GET","AjaxConversationRoom.php?Action="+str+"&sName="+sName,true);
    xmlhttp.send();
}
function ResetCommentModal(){
	var WritingZone = document.getElementById("CommentBuildingZone");
	var btnTrigger = document.getElementById("btnCreateComment");
	btnTrigger.style.display="block";
	WritingZone.style.display="none";
}
function OnClickHandler2(sElementName,sID){
	switch(sElementName){
		case "EditComment":
			EditComment(sID);
			GatherComments();
			break;
		case "RemoveComment":
			RemoveComment(sID);
			GatherComments();
			break;
		case "RegisterChange":
			ResetCommentModal();
			ModifyComment(sID);
			GatherComments();
			break;
		default:
			break;
	}
}
function OnClickHandler(sElementName){
	switch(sElementName){
		case "OpenMap":
			revealMap();
			break;
		case "Like":
			RegisterLike();
			break;
		case "CommentClose":
			var evtobj = window.event? event : e;
			closeComment(evtobj);
			break;
		case "Menue":
			document.getElementById("Menue").style.width="250px";
			break;
		case "closebtn":
			document.getElementById("Menue").style.width="0px";
			break;
		case "Comment":
			OpenComment(); 	
			break;
		case "Follow":
			RegisterFollow();
			break;
		case "CreateComment":
			CreateComment();
			break;
		case "Return":
			ResetCommentModal();
			break;
		case "RegisterChange":
			ResetCommentModal();
			AddComment();
			GatherComments();
			break;
		case "GetNextPost":
			var PostId = document.getElementById("currentPost").value;
			setCookie('PreviousPost',PostId,3);
			GetNextPost();
			break;
		case "Diconnect":
			DeleteAllCookie();
			break;
		default:
			break;
	}
}
function GetPost(idPost){
	var xmlhttp;
    var RequestCounter;
    var Action = "PHPCookieToJavascript";
    var Param = "id_user";
    var idUser;
    var idPost;
    RequestCounter=0;
    var request = "AjaxConversationRoom.php?Action="+Action+"&sName="+Param;

    var PostImage = document.getElementById("ImagePost");
    var PostAuthor = document.getElementById("UserName");
    var PostVues = document.getElementById("NbVue");
    var PostLikes = document.getElementById("NbLike");
    var PostID = document.getElementById("currentPost");
    var AuthorID = document.getElementById("currentAuthor");

    if (window.XMLHttpRequest){
        // code for IE7+, Firefox, Chrome, Opera, Safari
        xmlhttp=new XMLHttpRequest();
    }else{
        // code for IE6, IE5
        xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
    }
    if(marker !== undefined){
        mymap.removeLayer(marker);
    }
   	xmlhttp.onreadystatechange = function() {
        if (this.readyState == 4 && this.status == 200) {
        	if(RequestCounter==1){
        		idUser=this.responseText;
        		Action="GetPost";
    			RequestCounter+=1;
        		request = "AjaxConversationRoom.php?Action="+Action+"&IDPost="+idPost;
        		xmlhttp.open("GET",request,true);
    			xmlhttp.send();	
        	}else if(RequestCounter==2){
        		var sPost = this.responseText;
        		var a_sPost=sPost.split("\\");
        		var idUserB = a_sPost[1];
        	
        		AuthorID.setAttribute("value",a_sPost[1]);
        		PostID.setAttribute("value",a_sPost[0]);
        		PostImage.setAttribute("src",a_sPost[4]);
        		PostAuthor.innerHTML = a_sPost[5];
        		PostLikes.innerHTML = a_sPost[7];
        		PostVues.innerHTML = a_sPost[6];

        		var Lat = a_sPost[2];
        		var Long = a_sPost[3];
        		mymap.setView({lat:Lat,lng:Long}, 11, { animation: true }); 	
        		marker = new L.Marker([Lat,Long],{draggable:false}).addTo(mymap);
        		mymap.invalidateSize();

        		Action="CheckUserRelatedInformation";
        		RequestCounter+=1;
        		request = "AjaxConversationRoom.php?Action="+Action+"&IDPost="+idPost+"&IDUserA="+idUser+"&IDUserB="+idUserB;
        		xmlhttp.open("GET",request,true);
    			xmlhttp.send();	
			}else if(RequestCounter==3){
				a_sStyleUpdate = this.responseText.split("/");
				if(a_sStyleUpdate[0].length!=0){
                    alert(a_sStyleUpdate[0]);
                    alert("Yes Follow");
					document.getElementById("Follow").style = a_sStyleUpdate[0];
                    document.getElementById("IconFollow").setAttribute("class",'fa fa-users');
				}else{
                    alert(a_sStyleUpdate[0]);
                    alert("No Follow")
					document.getElementById("Follow").style = "background-color:none;";
                    document.getElementById("IconFollow").setAttribute("class",'fa fa-user-plus');
				}
				if(a_sStyleUpdate[1].length!=0){
					document.getElementById("Like").style = a_sStyleUpdate[1];
				}else{
					document.getElementById("Like").style = "background-color:none;";
				}
			}
	    }
	};
    xmlhttp.open("GET",request,true);
    xmlhttp.send();
    RequestCounter+=1;
}
function GetNextPost(){
	var xmlhttp;
    var RequestCounter;
    var Action = "PHPCookieToJavascript";
    var Param = "id_user";
    var idUser;
    var idPost;
    RequestCounter=0;
    var request = "AjaxConversationRoom.php?Action="+Action+"&sName="+Param;

    var PostImage = document.getElementById("ImagePost");
    var PostAuthor = document.getElementById("UserName");
    var PostVues = document.getElementById("NbVue");
    var PostLikes = document.getElementById("NbLike");
    var PostID = document.getElementById("currentPost");
    var AuthorID = document.getElementById("currentAuthor");

    if (window.XMLHttpRequest){
        // code for IE7+, Firefox, Chrome, Opera, Safari
        xmlhttp=new XMLHttpRequest();
    }else{
        // code for IE6, IE5
        xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
    }
    if(marker !== undefined){
        mymap.removeLayer(marker);
    }
   	xmlhttp.onreadystatechange = function() {
        if (this.readyState == 4 && this.status == 200) {
        	if(RequestCounter==1){
        		idUser = this.responseText;
        		Action = "FetchNewPost";
    			RequestCounter+=1;
        		request = "FetchingPostAlgo.php?Action="+Action+"&IDUser="+idUser;
        		xmlhttp.open("GET",request,true);
    			xmlhttp.send();
        	}else if(RequestCounter==2){
        		idPost = this.responseText;
        		Action="GetPost";
    			RequestCounter+=1;
        		request = "AjaxConversationRoom.php?Action="+Action+"&IDPost="+idPost;
        		xmlhttp.open("GET",request,true);
    			xmlhttp.send();	
        	}else if(RequestCounter==3){
        		var sPost = this.responseText;
        		var a_sPost=sPost.split("\\");
        		var idUserB = a_sPost[1];

				AuthorID.setAttribute("value",a_sPost[1]);
        		PostID.setAttribute("value",a_sPost[0]);
        		PostImage.setAttribute("src",a_sPost[4]);
        		PostAuthor.innerHTML = a_sPost[5];
        		PostLikes.innerHTML = a_sPost[7];
        		PostVues.innerHTML = a_sPost[6];

        		var Lat = a_sPost[2];
        		var Long = a_sPost[3];
        		mymap.setView({lat:Lat,lng:Long}, 11, { animation: true }); 	
        		marker = new L.Marker([Lat,Long],{draggable:false}).addTo(mymap);
        		mymap.invalidateSize();
				
				setCookie("PreviousPost",idPost,3);

				Action="CheckUserRelatedInformation";
        		RequestCounter+=1;
        		request = "AjaxConversationRoom.php?Action="+Action+"&IDPost="+idPost+"&IDUserA="+idUser+"&IDUserB="+idUserB;
        		xmlhttp.open("GET",request,true);
    			xmlhttp.send();	
			}else if(RequestCounter==4){
				a_sStyleUpdate = this.responseText.split("/");
				if(a_sStyleUpdate[0].length!=0){
					document.getElementById("Follow").style = a_sStyleUpdate[0];
                    document.getElementById("IconFollow").setAttribute("class",'fa fa-users');
				}else{
					document.getElementById("Follow").style = "background-color:none;";
                    document.getElementById("IconFollow").setAttribute("class",'fa fa-user-plus');
				}
				if(a_sStyleUpdate[1].length!=0){
					document.getElementById("Like").style = a_sStyleUpdate[1];
				}else{
					document.getElementById("Like").style = "background-color:none;";
				}
                document.getElementById("NbVue").innerHTML = parseInt(document.getElementById("NbVue").innerHTML)+1;
				Action="RegisterVisited";
        		RequestCounter+=1;
        		request = "AjaxConversationRoom.php?Action="+Action+"&IDPost="+idPost+"&IDUser="+idUser;
        		xmlhttp.open("GET",request,true);
    			xmlhttp.send();	
			}
	    }
	};
    xmlhttp.open("GET",request,true);
    xmlhttp.send();
    RequestCounter+=1;
}
function EditComment(idComment){
	var btnTrigger = document.getElementById("btnCreateComment");
	var WritingZone = document.getElementById("CommentBuildingZone");
	var btnRegister = document.getElementById("btnRegister");
	
	GetCommentContent(idComment);

	btnTrigger.style.display="none";
	btnRegister.setAttribute("onClick",'OnClickHandler2("RegisterChange",'+idComment+')');
	WritingZone.style.display = "flex";	

}
function closeComment(event){
	var modal = document.getElementById("CommentModal");
	var closebtn = document.getElementById("CloseBtn");
  	if (event.target == closebtn) {
   		modal.style.display = "none";
 	}
}
function OpenComment(){
	GatherComments();
	var modal = document.getElementById("CommentModal");
	modal.style.display = "block";
	CommentTransition(modal);
}
function revealMap(){
  modal.style.display = "block";
  mymap._onResize();
}
function CommentTransition(elem) {
  var pos = findPos(elem)[0];
  var id = setInterval(frame, 5);
  var win = window;
  function frame() {
    if (pos >= (win.innerWidth/6)) {
      clearInterval(id);
    } else {
      pos+=3; 
      elem.style.left = pos + "px"; 
    }
  }
}
function CreateComment(){
	var btnTrigger = document.getElementById("btnCreateComment");
	var WritingZone = document.getElementById("CommentBuildingZone");
	var btnRegister = document.getElementById("btnRegister");

	CKEDITOR.instances.NewComment.setData("");
	btnTrigger.style.display="none";
	btnRegister.setAttribute("onClick",'OnClickHandler("RegisterChange")');
	WritingZone.style.display = "flex";
}
function findPos(obj) {
	var curleft = curtop = 0;
	if (obj.offsetParent) {
		do {
			curleft += obj.offsetLeft;
			curtop += obj.offsetTop;
		} while (obj = obj.offsetParent);
	}
	return [curleft,curtop];

}