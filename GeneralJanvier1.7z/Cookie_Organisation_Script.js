function setCookie(CookieName,CookieValue,exHours){
	var d = new Date();
	d.setTime(d.getTime() + (exHours*60*60*1000));
	var expires = "expires="+d.toUTCString();
	document.cookie = CookieName+"="+CookieValue+";"+expires+";path=/";
}
function getCookie(CookieName){
	var sIndex = CookieName + "=";
	var CookieGroup = document.cookie.split(';');
 	for(var iIndex = 0; iIndex < CookieGroup.length; iIndex++) {
    	var Cookie = CookieGroup[iIndex];
    	while (Cookie.charAt(0) == ' ') {
      		Cookie = Cookie.substring(1);
    	}
    	if (Cookie.indexOf(sIndex) == 0) {
      		return Cookie.substring(sIndex.length, Cookie.length);
    	}
  	}
  	return "";
}
function checkCookie(CookieName){
	var cookie = getCookie(CookieName);
	if(cookie!=""){
		return true;
	}else{
		return false;
	}
}
function DeleteAllCookie(){
	var sIndex = CookieName + "=";
	var CookieGroup = document.cookie.split(';');
 	document.cookie="";
 	var CookieGroupFin = document.cookie;
 	alert(CookieGroup);
 	alert(CookieGroupFin);
}
function Check(){
	if(getCookie("Username")==""){
		sDirectory = window.location.pathname;
		sDirectory = sDirectory.split("/");
		sDirectory=sDirectory[1];
		window.location.replace(window.location.protocol+'/'+sDirectory+'/Connection.php');
	}
}